/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectojframe;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author brand
 */
public class Auditorio extends javax.swing.JFrame {

    /**
     * Creates new form Auditorio
     */
    // ====== MODELO (solo arreglos) ======
private static final int DURACION_MIN = 120; // 2 horas (10-12 y 3-5). Cambia si ocupás otro.
private static final int SLOTS = 2;          // 0 = primer bloque, 1 = segundo bloque
private static final int CAPACIDAD = 30;     // 30 personas por horario
// Estado por horario (persisten mientras la app esté abierta)
private static String[][] audSocios = new String[SLOTS][CAPACIDAD]; // IDs
private static long[]     audInicio = new long[SLOTS];              // millis inicio por slot

// Selección en UI
private int slotSeleccionado = -1;

// Para pintar fácil
private javax.swing.JButton[] btnsSlot;

    public Auditorio() {
        initComponents();
        escalarLogo();
        // Mapea los botones de horario. Usa los nombres EXACTOS que trae tu clase:
btnsSlot = new javax.swing.JButton[]{
    btn_hora_1pm, // ← primer bloque (ajústalo si en tu UI es 10-12)
    btn_hora_3pm  // ← segundo bloque (3-5)
};

// Pinta el estado guardado
refrescarColores();

    }
// ================== LÓGICA ==================
private void seleccionar(int slot) { //Define variables
    slotSeleccionado = slot;
    refrescarColores();
}

private void refrescarColores() {
    java.awt.Color normal = new java.awt.Color(200,200,200);
    java.awt.Color reservado = new java.awt.Color(120,120,120);
    java.awt.Color seleccionado = new java.awt.Color(0,153,255);

    for (int i = 0; i < SLOTS; i++) {
        javax.swing.JButton b = btnsSlot[i];
        boolean ocupado = (audSocios[i][0] != null); // si el primero no es null, hay reserva cargada
        b.setBackground(ocupado ? reservado : normal);
        if (slotSeleccionado == i) b.setBackground(seleccionado);
    }
}

private void reservar() { //Mpetodo para reservar
    if (slotSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
        return;
    }

    // Si ya hay gente cargada en ese horario, bloquear
    if (audSocios[slotSeleccionado][0] != null) {
        javax.swing.JOptionPane.showMessageDialog(this, "Ese horario ya tiene una reserva cargada (30 personas). Libérela para volver a cargar.");
        return;
    }

    // Recolectar EXACTAMENTE 30 IDs válidos y únicos (dentro del horario)
    String[] temp = new String[CAPACIDAD];
    for (int i = 0; i < CAPACIDAD; i++) {
        String id = javax.swing.JOptionPane.showInputDialog(this, "Digite el ID del socio #" + (i+1) + " (30 en total):");
        if (id == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "Reserva cancelada. No se guardó nada.");
            return; // aborta todo
        }
        id = id.trim();
        if (id.isEmpty()) { i--; continue; } // vuelve a pedir el mismo número

        // Validar existencia del socio en Socio_Registrar
        int fila = buscarFilaSocioPorId(id);
        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "El ID '" + id + "' no existe. Intente de nuevo.");
            i--; 
            continue;
        }

        // Validar NO repetición dentro del mismo horario
        if (existeEnArreglo(temp, id)) {
            javax.swing.JOptionPane.showMessageDialog(this, "El ID '" + id + "' ya fue agregado para este horario.");
            i--;
            continue;
        }

        temp[i] = id;
    }

    // Copiar a estado y fijar inicio
    for (int i = 0; i < CAPACIDAD; i++) audSocios[slotSeleccionado][i] = temp[i];
    audInicio[slotSeleccionado] = System.currentTimeMillis();

    javax.swing.JOptionPane.showMessageDialog(this, "Reserva del horario cargada con 30 personas.");
    refrescarColores();
}

private void verInformacion() {
    if (slotSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
        return;
    }
    if (audSocios[slotSeleccionado][0] == null) {
        javax.swing.JOptionPane.showMessageDialog(this, "El horario está libre.");
        return;
    }

    long ini = audInicio[slotSeleccionado];
    long minPasados = (System.currentTimeMillis() - ini) / 60000;
    long minRest = Math.max(0, DURACION_MIN - minPasados);

    // Construir listado (ID - Nombre)
    StringBuilder sb = new StringBuilder();
    sb.append("Horario: ").append(btnsSlot[slotSeleccionado].getText())
      .append("\nMinutos restantes: ").append(minRest).append(" min")
      .append("\nPersonas (30):\n");

    for (int i = 0; i < CAPACIDAD; i++) {
        String id = audSocios[slotSeleccionado][i];
        int fila = (id != null) ? buscarFilaSocioPorId(id) : -1;
        String nombre = (fila >= 0) ? Socio_Registrar.socios[fila][1] : "(desconocido)";
        sb.append(String.format("%2d) %s - %s%n", (i+1), id, nombre));
    }

    javax.swing.JOptionPane.showMessageDialog(this, sb.toString());
}

private void liberar() {
    if (slotSeleccionado == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
        return;
    }
    if (audSocios[slotSeleccionado][0] == null) {
        javax.swing.JOptionPane.showMessageDialog(this, "Ese horario ya está libre.");
        return;
    }
    int opt = javax.swing.JOptionPane.showConfirmDialog(this, "¿Cancelar la reservación (se borran los 30 IDs)?", "Confirmar",
            javax.swing.JOptionPane.YES_NO_OPTION);
    if (opt != javax.swing.JOptionPane.YES_OPTION) return;

    for (int i = 0; i < CAPACIDAD; i++) audSocios[slotSeleccionado][i] = null;
    audInicio[slotSeleccionado] = 0L;

    javax.swing.JOptionPane.showMessageDialog(this, "Reservación liberada.");
    refrescarColores();
}

// ================== AUXILIARES ==================
private int buscarFilaSocioPorId(String id) {
    for (int i = 0; i < Socio_Registrar.socios.length; i++) {
        if (Socio_Registrar.socios[i][0] != null && Socio_Registrar.socios[i][0].equals(id)) {
            return i;
        }
    }
    return -1;
}

private boolean existeEnArreglo(String[] arr, String id) {
    for (int i = 0; i < arr.length; i++) {
        if (id.equals(arr[i])) return true;
    }
    return false;
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Img_logo = new javax.swing.JLabel();
        txt_bienvenida = new javax.swing.JLabel();
        btn_hora_1pm = new javax.swing.JButton();
        btn_hora_3pm = new javax.swing.JButton();
        btn_reservar = new javax.swing.JButton();
        btn_liberar = new javax.swing.JButton();
        btn_información = new javax.swing.JButton();
        pn_secundario8 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        btn_socio8 = new javax.swing.JButton();
        btn_parqueo8 = new javax.swing.JButton();
        btn_pesas8 = new javax.swing.JButton();
        btn_cabinaAction8 = new javax.swing.JButton();
        btn_recreacion8 = new javax.swing.JButton();
        btn_auditorio8 = new javax.swing.JButton();
        btn_clasesGrupales7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        Img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iñasfit logo.jpg"))); // NOI18N
        Img_logo.setText("jLabel2");
        Img_logo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Img_logo.setIconTextGap(0);

        txt_bienvenida.setBackground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txt_bienvenida.setForeground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txt_bienvenida.setText("Seleccione el horario");

        btn_hora_1pm.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_hora_1pm.setText("10am-12am");
        btn_hora_1pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hora_1pmActionPerformed(evt);
            }
        });

        btn_hora_3pm.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_hora_3pm.setText("3pm-5pm");
        btn_hora_3pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hora_3pmActionPerformed(evt);
            }
        });

        btn_reservar.setBackground(new java.awt.Color(0, 204, 204));
        btn_reservar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_reservar.setForeground(new java.awt.Color(255, 255, 255));
        btn_reservar.setText("Reservar");
        btn_reservar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_reservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_reservarActionPerformed(evt);
            }
        });

        btn_liberar.setBackground(new java.awt.Color(0, 204, 204));
        btn_liberar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_liberar.setForeground(new java.awt.Color(255, 255, 255));
        btn_liberar.setText("Liberar");
        btn_liberar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_liberar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_liberarActionPerformed(evt);
            }
        });

        btn_información.setBackground(new java.awt.Color(0, 204, 204));
        btn_información.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_información.setForeground(new java.awt.Color(255, 255, 255));
        btn_información.setText("Información");
        btn_información.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_información.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_informaciónActionPerformed(evt);
            }
        });

        pn_secundario8.setBackground(new java.awt.Color(0, 204, 204));
        pn_secundario8.setForeground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("Administración  Gimnasio");

        btn_socio8.setBackground(new java.awt.Color(0, 204, 204));
        btn_socio8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_socio8.setForeground(new java.awt.Color(255, 255, 255));
        btn_socio8.setText("Socio");
        btn_socio8.setActionCommand("btn_socio");
        btn_socio8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_socio8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_socio8ActionPerformed(evt);
            }
        });

        btn_parqueo8.setBackground(new java.awt.Color(0, 204, 204));
        btn_parqueo8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_parqueo8.setForeground(new java.awt.Color(255, 255, 255));
        btn_parqueo8.setText("Parqueo");
        btn_parqueo8.setActionCommand("btn_parqueo");
        btn_parqueo8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_parqueo8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_parqueo8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_parqueo8ActionPerformed(evt);
            }
        });

        btn_pesas8.setBackground(new java.awt.Color(0, 204, 204));
        btn_pesas8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_pesas8.setForeground(new java.awt.Color(255, 255, 255));
        btn_pesas8.setText("Sala de pesas");
        btn_pesas8.setActionCommand("btn_pesas");
        btn_pesas8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_pesas8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_pesas8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pesas8ActionPerformed(evt);
            }
        });

        btn_cabinaAction8.setBackground(new java.awt.Color(0, 204, 204));
        btn_cabinaAction8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cabinaAction8.setForeground(new java.awt.Color(255, 255, 255));
        btn_cabinaAction8.setText("Cabinas");
        btn_cabinaAction8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cabinaAction8.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction8.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_cabinaAction8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cabinaAction8ActionPerformed(evt);
            }
        });

        btn_recreacion8.setBackground(new java.awt.Color(0, 204, 204));
        btn_recreacion8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_recreacion8.setForeground(new java.awt.Color(255, 255, 255));
        btn_recreacion8.setText("Recreación");
        btn_recreacion8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_recreacion8.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_recreacion8.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_recreacion8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_recreacion8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_recreacion8ActionPerformed(evt);
            }
        });

        btn_auditorio8.setBackground(new java.awt.Color(0, 204, 204));
        btn_auditorio8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_auditorio8.setForeground(new java.awt.Color(255, 255, 255));
        btn_auditorio8.setText("Auditorio");
        btn_auditorio8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_auditorio8.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_auditorio8.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_auditorio8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_auditorio8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_auditorio8ActionPerformed(evt);
            }
        });

        btn_clasesGrupales7.setBackground(new java.awt.Color(0, 204, 204));
        btn_clasesGrupales7.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_clasesGrupales7.setForeground(new java.awt.Color(255, 255, 255));
        btn_clasesGrupales7.setText("Clases Grupales");
        btn_clasesGrupales7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_clasesGrupales7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clasesGrupales7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_secundario8Layout = new javax.swing.GroupLayout(pn_secundario8);
        pn_secundario8.setLayout(pn_secundario8Layout);
        pn_secundario8Layout.setHorizontalGroup(
            pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario8Layout.createSequentialGroup()
                .addGroup(pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_secundario8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pn_secundario8Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_auditorio8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_recreacion8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pn_secundario8Layout.createSequentialGroup()
                                .addGroup(pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_cabinaAction8, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                                    .addComponent(btn_socio8, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                                    .addComponent(btn_parqueo8, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                                    .addComponent(btn_clasesGrupales7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_secundario8Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_pesas8, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pn_secundario8Layout.setVerticalGroup(
            pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_socio8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_parqueo8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_clasesGrupales7, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_pesas8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_cabinaAction8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_recreacion8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_auditorio8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(pn_secundario8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71)
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addComponent(btn_reservar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(45, 45, 45)
                                .addComponent(btn_liberar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(47, 47, 47)
                                .addComponent(btn_información, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(119, 119, 119)
                                .addComponent(btn_hora_1pm, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(btn_hora_3pm, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(1005, 1005, 1005))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(txt_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_hora_3pm, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_hora_1pm, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(99, 99, 99)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(btn_liberar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_reservar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_información, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(109, Short.MAX_VALUE))
            .addComponent(pn_secundario8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_hora_1pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hora_1pmActionPerformed
        // TODO add your handling code here:
        seleccionar(0);
    }//GEN-LAST:event_btn_hora_1pmActionPerformed

    private void btn_hora_3pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hora_3pmActionPerformed
        // TODO add your handling code here:
        seleccionar(1);
    }//GEN-LAST:event_btn_hora_3pmActionPerformed

    private void btn_liberarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_liberarActionPerformed
        // TODO add your handling code here:
        liberar();
    }//GEN-LAST:event_btn_liberarActionPerformed

    private void btn_informaciónActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_informaciónActionPerformed
        // TODO add your handling code here:
        verInformacion();
    }//GEN-LAST:event_btn_informaciónActionPerformed

    private void btn_reservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_reservarActionPerformed
        // TODO add your handling code here:
        reservar();
    }//GEN-LAST:event_btn_reservarActionPerformed

    private void btn_socio8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_socio8ActionPerformed
        // TODO add your handling code here:
        Socio socio = new Socio();

        socio.setVisible(true); //Activa la interfaz socio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_socio8ActionPerformed

    private void btn_parqueo8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_parqueo8ActionPerformed
        // TODO add your handling code here:
        Parqueo parqueo = new Parqueo();

        parqueo.setVisible(true); //Activa la interfaz Parqueo
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_parqueo8ActionPerformed

    private void btn_pesas8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pesas8ActionPerformed
        // TODO add your handling code here:
        Sala_Pesas sala_pesas = new Sala_Pesas();

        sala_pesas.setVisible(true); //Activa la interfaz sala de pesas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_pesas8ActionPerformed

    private void btn_cabinaAction8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cabinaAction8ActionPerformed
        Cabina cabinas = new Cabina();

        cabinas.setVisible(true); //Activa la interfaz de cabinas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_cabinaAction8ActionPerformed

    private void btn_recreacion8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_recreacion8ActionPerformed
        // TODO add your handling code here:
        Recreacion recreacion = new Recreacion();

        recreacion.setVisible(true); //Activa la interfaz de recreación
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_recreacion8ActionPerformed

    private void btn_auditorio8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_auditorio8ActionPerformed
        Auditorio auditorio = new Auditorio();

        auditorio.setVisible(true); //Activa la interfaz de auditorio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_auditorio8ActionPerformed

    private void btn_clasesGrupales7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clasesGrupales7ActionPerformed
        // TODO add your handling code here:
        ClaseGrupal claseGrupal = new ClaseGrupal();

        claseGrupal.setVisible(true); //Activa la interfaz de ClaseGrupal
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_clasesGrupales7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Auditorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Auditorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Auditorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Auditorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Auditorio().setVisible(true);
            }
        });
    }
    // metodo logo
    private void escalarLogo() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/iñasfit logo.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                Img_logo.getWidth(),
                Img_logo.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        Img_logo.setIcon(new ImageIcon(imagenEscalada));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Img_logo;
    private javax.swing.JButton btn_auditorio8;
    private javax.swing.JButton btn_cabinaAction8;
    private javax.swing.JButton btn_clasesGrupales7;
    private javax.swing.JButton btn_hora_1pm;
    private javax.swing.JButton btn_hora_3pm;
    private javax.swing.JButton btn_información;
    private javax.swing.JButton btn_liberar;
    private javax.swing.JButton btn_parqueo8;
    private javax.swing.JButton btn_pesas8;
    private javax.swing.JButton btn_recreacion8;
    private javax.swing.JButton btn_reservar;
    private javax.swing.JButton btn_socio8;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel pn_secundario8;
    private javax.swing.JLabel txt_bienvenida;
    // End of variables declaration//GEN-END:variables
}
