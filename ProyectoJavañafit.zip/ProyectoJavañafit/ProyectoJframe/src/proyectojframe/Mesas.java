/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectojframe;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author brand
 */
public class Mesas extends javax.swing.JFrame {

    /**
     * Creates new form Mesas
     */
    private final int DURACION_MIN = 30;

// 7 slots por mesa según tu interfaz
    private final int SLOTS = 7;

// Estado de reservas (por mesa y por slot)
    private static String[] billarSocioId = new String[7];
    private static long[] billarInicio = new long[7];
    private static String[] pingSocioId = new String[7];
    private static long[] pingInicio = new long[7];
// Selección actual del usuario en pantalla
// mesa: 0 = Billar, 1 = PingPong; -1 = nada
    private int mesaSeleccionada = -1;
// slot seleccionado: 0..6; -1 = ninguno
    private int slotSeleccionado = -1;

// Arreglos de botones para mapear índice <-> botón
    private javax.swing.JButton[] btnsBillar;
    private javax.swing.JButton[] btnsPing;

    public Mesas() {
        initComponents();
        escalarLogo();
        // Mapear botones por orden visual (0..6)
        btnsBillar = new javax.swing.JButton[]{
            btn_930am_billar, btn_10am_billar, btn_1030am_billar,
            btn_11am_billar, btn_1130am_billar, btn_12pm_billar, btn_1230pm_billar
        };

        btnsPing = new javax.swing.JButton[]{
            btn_930am_pingPong, btn_10am_pingPong, btn_1030am_pingPong,
            btn_11am_pingPong, btn_1130am_pingPong, btn_12pm_pingPong, btn_1230pm_pingPong
        };

// Listeners de selección (billar)
        for (int i = 0; i < btnsBillar.length; i++) {
            final int idx = i;
            btnsBillar[i].addActionListener(e -> seleccionar(0, idx));
        }

// Listeners de selección (ping pong)
        for (int i = 0; i < btnsPing.length; i++) {
            final int idx = i;
            btnsPing[i].addActionListener(e -> seleccionar(1, idx));
        }

// Pintar estado inicial
        refrescarColores();
    }
    // ================== LÓGICA ==================

    private void seleccionar(int mesa, int slot) {
        mesaSeleccionada = mesa;
        slotSeleccionado = slot;
        refrescarColores();
    }

    private void refrescarColores() {
        java.awt.Color normal = new java.awt.Color(200, 200, 200);
        java.awt.Color reservado = new java.awt.Color(120, 120, 120);
        java.awt.Color seleccionado = new java.awt.Color(0, 153, 255);

        // Billar
        for (int i = 0; i < SLOTS; i++) {
            javax.swing.JButton b = btnsBillar[i];
            boolean ocupado = (billarSocioId[i] != null);
            b.setBackground(ocupado ? reservado : normal);
            if (mesaSeleccionada == 0 && slotSeleccionado == i) {
                b.setBackground(seleccionado);
            }
        }
        // Ping
        for (int i = 0; i < SLOTS; i++) {
            javax.swing.JButton b = btnsPing[i];
            boolean ocupado = (pingSocioId[i] != null);
            b.setBackground(ocupado ? reservado : normal);
            if (mesaSeleccionada == 1 && slotSeleccionado == i) {
                b.setBackground(seleccionado);
            }
        }
    }

    private void reservar() {
        if (mesaSeleccionada == -1 || slotSeleccionado == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
            return;
        }

        // Pedir ID socio por JOP
        String id = javax.swing.JOptionPane.showInputDialog(this, "Digite el ID del socio para reservar:");
        if (id == null || id.trim().isEmpty()) {
            return;
        }
        id = id.trim();

        // Validar que exista el socio
        int filaSocio = buscarFilaSocioPorId(id);
        if (filaSocio == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "El ID no existe.");
            return;
        }

        // Verificar que el socio NO tenga otra reserva activa
        if (socioTieneReservaActiva(id)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ese socio ya tiene una mesa reservada. Solo una x dia.");
            return;
        }

        // Verificar que el slot no esté ocupado
        if (estaOcupado(mesaSeleccionada, slotSeleccionado)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ese horario ya está reservado.");
            return;
        }

        // Registrar
        if (mesaSeleccionada == 0) {
            billarSocioId[slotSeleccionado] = id;
            billarInicio[slotSeleccionado] = System.currentTimeMillis();
        } else {
            pingSocioId[slotSeleccionado] = id;
            pingInicio[slotSeleccionado] = System.currentTimeMillis();
        }

        javax.swing.JOptionPane.showMessageDialog(this, "Reserva confirmada para el socio: "
                + Socio_Registrar.socios[filaSocio][1] + " (ID " + id + ").");
        refrescarColores();
    }

    private void verInformacion() {
        if (mesaSeleccionada == -1 || slotSeleccionado == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
            return;
        }

        String id = obtenerSocioEnSlot(mesaSeleccionada, slotSeleccionado);
        if (id == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "El horario está libre.");
            return;
        }

        int fila = buscarFilaSocioPorId(id);
        String nombre = (fila >= 0) ? Socio_Registrar.socios[fila][1] : "(desconocido)";

        long ini = (mesaSeleccionada == 0) ? billarInicio[slotSeleccionado] : pingInicio[slotSeleccionado];
        long minutosPasados = (System.currentTimeMillis() - ini) / 60000;
        long minutosRestantes = Math.max(0, DURACION_MIN - minutosPasados);

        String mesaTxt = (mesaSeleccionada == 0) ? "Billar" : "Ping Pong";
        javax.swing.JOptionPane.showMessageDialog(this,
                "Mesa: " + mesaTxt
                + "\nHorario seleccionado: " + textoBotonActual()
                + "\nSocio: " + nombre
                + "\nID: " + id
                + "\nMinutos restantes: " + minutosRestantes + " min");
    }

    private void liberar() {
        if (mesaSeleccionada == -1 || slotSeleccionado == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
            return;
        }

        String id = obtenerSocioEnSlot(mesaSeleccionada, slotSeleccionado);
        if (id == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ese horario ya está libre.");
            return;
        }

        int opt = javax.swing.JOptionPane.showConfirmDialog(this, "¿Cancelar la reservación?", "Confirmar", javax.swing.JOptionPane.YES_NO_OPTION);
        if (opt != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        if (mesaSeleccionada == 0) {
            billarSocioId[slotSeleccionado] = null;
            billarInicio[slotSeleccionado] = 0L;
        } else {
            pingSocioId[slotSeleccionado] = null;
            pingInicio[slotSeleccionado] = 0L;
        }
        javax.swing.JOptionPane.showMessageDialog(this, "Reservación liberada.");
        refrescarColores();
    }

// ================== AUXILIARES ==================
    private boolean estaOcupado(int mesa, int slot) {
        if (mesa == 0) {
            return billarSocioId[slot] != null;
        }
        return pingSocioId[slot] != null;
    }

    private String obtenerSocioEnSlot(int mesa, int slot) {
        if (mesa == 0) {
            return billarSocioId[slot];
        }
        return pingSocioId[slot];
    }

    private int buscarFilaSocioPorId(String id) {
        // Busca en Socio_Registrar.socios[][] donde [0] es ID
        for (int i = 0; i < Socio_Registrar.socios.length; i++) {
            if (Socio_Registrar.socios[i][0] != null && Socio_Registrar.socios[i][0].equals(id)) {
                return i;
            }
        }
        return -1;
    }

    private boolean socioTieneReservaActiva(String id) {
        // Revisa todos los slots de ambas mesas
        for (int i = 0; i < SLOTS; i++) {
            if (id.equals(billarSocioId[i])) {
                if (tiempoRestante(billarInicio[i]) > 0) {
                    return true;
                }
            }
            if (id.equals(pingSocioId[i])) {
                if (tiempoRestante(pingInicio[i]) > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    private long tiempoRestante(long inicio) {
        long min = (System.currentTimeMillis() - inicio) / 60000;
        return Math.max(0, DURACION_MIN - min);
    }

    private String textoBotonActual() {
        if (mesaSeleccionada == -1 || slotSeleccionado == -1) {
            return "";
        }
        javax.swing.JButton b = (mesaSeleccionada == 0) ? btnsBillar[slotSeleccionado] : btnsPing[slotSeleccionado];
        return b.getText();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Img_logo = new javax.swing.JLabel();
        txt_bienvenida = new javax.swing.JLabel();
        txt_bienvenida1 = new javax.swing.JLabel();
        txt_bienvenida2 = new javax.swing.JLabel();
        btn_930am_billar = new javax.swing.JButton();
        btn_10am_billar = new javax.swing.JButton();
        btn_1030am_billar = new javax.swing.JButton();
        btn_11am_billar = new javax.swing.JButton();
        btn_1130am_billar = new javax.swing.JButton();
        btn_12pm_billar = new javax.swing.JButton();
        btn_1230pm_billar = new javax.swing.JButton();
        btn_930am_pingPong = new javax.swing.JButton();
        btn_10am_pingPong = new javax.swing.JButton();
        btn_1030am_pingPong = new javax.swing.JButton();
        btn_11am_pingPong = new javax.swing.JButton();
        btn_1130am_pingPong = new javax.swing.JButton();
        btn_12pm_pingPong = new javax.swing.JButton();
        btn_1230pm_pingPong = new javax.swing.JButton();
        btn_reservar = new javax.swing.JButton();
        btn_liberar = new javax.swing.JButton();
        btn_Información = new javax.swing.JButton();
        btn_volver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        Img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iñasfit logo.jpg"))); // NOI18N
        Img_logo.setText("jLabel2");
        Img_logo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Img_logo.setIconTextGap(0);

        txt_bienvenida.setBackground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txt_bienvenida.setForeground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txt_bienvenida.setText("Seleccione la mesa");

        txt_bienvenida1.setBackground(new java.awt.Color(0, 0, 0));
        txt_bienvenida1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txt_bienvenida1.setForeground(new java.awt.Color(0, 0, 0));
        txt_bienvenida1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txt_bienvenida1.setText("Billar");

        txt_bienvenida2.setBackground(new java.awt.Color(0, 0, 0));
        txt_bienvenida2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txt_bienvenida2.setForeground(new java.awt.Color(0, 0, 0));
        txt_bienvenida2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txt_bienvenida2.setText("Ping Pong");

        btn_930am_billar.setText("9:30am-10am");
        btn_930am_billar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_930am_billarActionPerformed(evt);
            }
        });

        btn_10am_billar.setText("10am-10:30am");
        btn_10am_billar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_10am_billarActionPerformed(evt);
            }
        });

        btn_1030am_billar.setText("10:30am-11am");
        btn_1030am_billar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1030am_billarActionPerformed(evt);
            }
        });

        btn_11am_billar.setText("11am-11:30am");
        btn_11am_billar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_11am_billarActionPerformed(evt);
            }
        });

        btn_1130am_billar.setText("11:30am-12pm");
        btn_1130am_billar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1130am_billarActionPerformed(evt);
            }
        });

        btn_12pm_billar.setText("12pm-12:30pm");
        btn_12pm_billar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_12pm_billarActionPerformed(evt);
            }
        });

        btn_1230pm_billar.setText("12:30pm-1pm");
        btn_1230pm_billar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1230pm_billarActionPerformed(evt);
            }
        });

        btn_930am_pingPong.setText("9:30am-10am");
        btn_930am_pingPong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_930am_pingPongActionPerformed(evt);
            }
        });

        btn_10am_pingPong.setText("10am-10:30am");
        btn_10am_pingPong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_10am_pingPongActionPerformed(evt);
            }
        });

        btn_1030am_pingPong.setText("10:30am-11am");
        btn_1030am_pingPong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1030am_pingPongActionPerformed(evt);
            }
        });

        btn_11am_pingPong.setText("11am-11:30am");
        btn_11am_pingPong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_11am_pingPongActionPerformed(evt);
            }
        });

        btn_1130am_pingPong.setText("11:30am-12pm");
        btn_1130am_pingPong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1130am_pingPongActionPerformed(evt);
            }
        });

        btn_12pm_pingPong.setText("12pm-12:30pm");
        btn_12pm_pingPong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_12pm_pingPongActionPerformed(evt);
            }
        });

        btn_1230pm_pingPong.setText("12:30pm-1pm");
        btn_1230pm_pingPong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1230pm_pingPongActionPerformed(evt);
            }
        });

        btn_reservar.setBackground(new java.awt.Color(0, 204, 204));
        btn_reservar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_reservar.setForeground(new java.awt.Color(255, 255, 255));
        btn_reservar.setText("Reservar");
        btn_reservar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_reservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_reservarActionPerformed(evt);
            }
        });

        btn_liberar.setBackground(new java.awt.Color(0, 204, 204));
        btn_liberar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_liberar.setForeground(new java.awt.Color(255, 255, 255));
        btn_liberar.setText("Liberar");
        btn_liberar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_liberar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_liberarActionPerformed(evt);
            }
        });

        btn_Información.setBackground(new java.awt.Color(0, 204, 204));
        btn_Información.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_Información.setForeground(new java.awt.Color(255, 255, 255));
        btn_Información.setText("Información");
        btn_Información.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_Información.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_InformaciónActionPerformed(evt);
            }
        });

        btn_volver.setBackground(new java.awt.Color(0, 204, 204));
        btn_volver.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_volver.setForeground(new java.awt.Color(255, 255, 255));
        btn_volver.setText("Volver");
        btn_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_volverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(242, 242, 242)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btn_930am_billar, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_10am_billar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_1030am_billar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_11am_billar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_1130am_billar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_12pm_billar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_1230pm_billar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(btn_reservar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_liberar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btn_930am_pingPong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_10am_pingPong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_1030am_pingPong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_11am_pingPong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_1130am_pingPong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_12pm_pingPong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_1230pm_pingPong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(btn_Información, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_bienvenida)
                        .addGap(140, 140, 140))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(302, 302, 302)
                        .addComponent(txt_bienvenida1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_bienvenida2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))
                    .addComponent(btn_volver, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_bienvenida2)
                            .addComponent(txt_bienvenida1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_930am_billar)
                            .addComponent(btn_930am_pingPong))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_10am_pingPong)
                            .addComponent(btn_10am_billar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_1030am_pingPong)
                            .addComponent(btn_1030am_billar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_11am_pingPong)
                            .addComponent(btn_11am_billar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_1130am_pingPong)
                            .addComponent(btn_1130am_billar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_12pm_pingPong)
                            .addComponent(btn_12pm_billar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_1230pm_pingPong)
                            .addComponent(btn_1230pm_billar))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_reservar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_liberar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Información, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(97, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_volver, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_volverActionPerformed
        // TODO add your handling code here:
        Recreacion recreacion = new Recreacion();

        recreacion.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_volverActionPerformed

    private void btn_reservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_reservarActionPerformed
        // TODO add your handling code here:
        reservar();
    }//GEN-LAST:event_btn_reservarActionPerformed

    private void btn_liberarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_liberarActionPerformed
        // TODO add your handling code here:
        liberar();
    }//GEN-LAST:event_btn_liberarActionPerformed

    private void btn_InformaciónActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_InformaciónActionPerformed
        // TODO add your handling code here:
        verInformacion();
    }//GEN-LAST:event_btn_InformaciónActionPerformed

    private void btn_930am_billarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_930am_billarActionPerformed
        // TODO add your handling code here:
        seleccionar(0, 0); // mesa billar, slot 0
    }//GEN-LAST:event_btn_930am_billarActionPerformed

    private void btn_10am_billarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_10am_billarActionPerformed
        // TODO add your handling code here:
        seleccionar(0, 1); // mesa billar, slot 1
    }//GEN-LAST:event_btn_10am_billarActionPerformed

    private void btn_930am_pingPongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_930am_pingPongActionPerformed
        // TODO add your handling code here:
        seleccionar(1, 0); // mesa ping pong, slot 0
    }//GEN-LAST:event_btn_930am_pingPongActionPerformed

    private void btn_10am_pingPongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_10am_pingPongActionPerformed
        // TODO add your handling code here:
        seleccionar(1, 1); // mesa ping pong, slot 1
    }//GEN-LAST:event_btn_10am_pingPongActionPerformed

    private void btn_1030am_billarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1030am_billarActionPerformed
        // TODO add your handling code here:
        seleccionar(0, 2); // mesa billar, slot 3

    }//GEN-LAST:event_btn_1030am_billarActionPerformed

    private void btn_11am_billarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_11am_billarActionPerformed
        // TODO add your handling code here:
        seleccionar(0, 3); // mesa billar, slot 4
    }//GEN-LAST:event_btn_11am_billarActionPerformed

    private void btn_1130am_billarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1130am_billarActionPerformed
        // TODO add your handling code here:
        seleccionar(0, 4); // mesa billar, slot 5
    }//GEN-LAST:event_btn_1130am_billarActionPerformed

    private void btn_12pm_billarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_12pm_billarActionPerformed
        // TODO add your handling code here:
        seleccionar(0, 5); // mesa billar, slot 6
    }//GEN-LAST:event_btn_12pm_billarActionPerformed

    private void btn_1230pm_billarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1230pm_billarActionPerformed
        // TODO add your handling code here:
        seleccionar(0, 6); // mesa billar, slot 7
    }//GEN-LAST:event_btn_1230pm_billarActionPerformed

    private void btn_1030am_pingPongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1030am_pingPongActionPerformed
        // TODO add your handling code here:
            seleccionar(1, 2); // mesa ping pong, slot 3

        
    }//GEN-LAST:event_btn_1030am_pingPongActionPerformed

    private void btn_11am_pingPongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_11am_pingPongActionPerformed
        // TODO add your handling code here:
            seleccionar(1, 3); // mesa ping pong, slot 4

    }//GEN-LAST:event_btn_11am_pingPongActionPerformed

    private void btn_1130am_pingPongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1130am_pingPongActionPerformed
        // TODO add your handling code here:
            seleccionar(1, 4); // mesa ping pong, slot 5

    }//GEN-LAST:event_btn_1130am_pingPongActionPerformed

    private void btn_12pm_pingPongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_12pm_pingPongActionPerformed
        // TODO add your handling code here:
            seleccionar(1, 5); // mesa ping pong, slot 6

    }//GEN-LAST:event_btn_12pm_pingPongActionPerformed

    private void btn_1230pm_pingPongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1230pm_pingPongActionPerformed
        // TODO add your handling code here:
            seleccionar(1, 6); // mesa ping pong, slot 7

    }//GEN-LAST:event_btn_1230pm_pingPongActionPerformed
// metodo logo
    private void escalarLogo() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/iñasfit logo.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                Img_logo.getWidth(),
                Img_logo.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        Img_logo.setIcon(new ImageIcon(imagenEscalada));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Mesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Mesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Mesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Mesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Mesas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Img_logo;
    private javax.swing.JButton btn_1030am_billar;
    private javax.swing.JButton btn_1030am_pingPong;
    private javax.swing.JButton btn_10am_billar;
    private javax.swing.JButton btn_10am_pingPong;
    private javax.swing.JButton btn_1130am_billar;
    private javax.swing.JButton btn_1130am_pingPong;
    private javax.swing.JButton btn_11am_billar;
    private javax.swing.JButton btn_11am_pingPong;
    private javax.swing.JButton btn_1230pm_billar;
    private javax.swing.JButton btn_1230pm_pingPong;
    private javax.swing.JButton btn_12pm_billar;
    private javax.swing.JButton btn_12pm_pingPong;
    private javax.swing.JButton btn_930am_billar;
    private javax.swing.JButton btn_930am_pingPong;
    private javax.swing.JButton btn_Información;
    private javax.swing.JButton btn_liberar;
    private javax.swing.JButton btn_reservar;
    private javax.swing.JButton btn_volver;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel txt_bienvenida;
    private javax.swing.JLabel txt_bienvenida1;
    private javax.swing.JLabel txt_bienvenida2;
    // End of variables declaration//GEN-END:variables
}
