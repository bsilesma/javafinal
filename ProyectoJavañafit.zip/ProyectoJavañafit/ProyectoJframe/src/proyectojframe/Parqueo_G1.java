/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectojframe;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author pipe-
 */
public class Parqueo_G1 extends javax.swing.JFrame {

    /**
     * Creates new form Parqueo
     */
    private JButton[][] matrizBotones = new JButton[4][5]; // Creación de matríz 4 filas, 5 columnas

    private static String[][] estadoParqueo = { //Mapeado de botones
        {"D", "L", "L", "L", "E"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "E"}
    };
    private static String[][] estadoOriginal = { //Mapeado de botones
        {"D", "L", "L", "L", "E"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "E"}
    };
    private static String[][] parqueoIDs = new String[4][5];

    public Parqueo_G1() { //Llamado de métodos
        initComponents();
        escalarLogo();
        inicializarMatrizBotones();
        actualizarTextoBotones();
        configurarAccionesBotones();

    }

    private void inicializarMatrizBotones() { //Definición de la matriz por orden
        matrizBotones[0][0] = btn_1_1;
        matrizBotones[0][1] = btn_1_2;
        matrizBotones[0][2] = btn_1_3;
        matrizBotones[0][3] = btn_1_4;
        matrizBotones[0][4] = btn_1_5;

        matrizBotones[1][0] = btn_2_1;
        matrizBotones[1][1] = btn_2_2;
        matrizBotones[1][2] = btn_2_3;
        matrizBotones[1][3] = btn_2_4;
        matrizBotones[1][4] = btn_2_5;

        matrizBotones[2][0] = btn_3_1;
        matrizBotones[2][1] = btn_3_2;
        matrizBotones[2][2] = btn_3_3;
        matrizBotones[2][3] = btn_3_4;
        matrizBotones[2][4] = btn_3_5;

        matrizBotones[3][0] = btn_4_1;
        matrizBotones[3][1] = btn_4_2;
        matrizBotones[3][2] = btn_4_3;
        matrizBotones[3][3] = btn_4_4;
        matrizBotones[3][4] = btn_4_5;
        
      
    }

    private void actualizarTextoBotones() { //For para actualizar el mapeado de la interfaz
        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                matrizBotones[fila][col].setText(estadoParqueo[fila][col]);
            }
        }
    }

    private void registrarOcupacion() { //Método para registrar 
        boolean espacioSeleccionado = false;

        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                JButton boton = matrizBotones[fila][col];

                if (boton.getBackground() != null && boton.getBackground().equals(Color.CYAN)) { //Acción para cambiar el color
                    String estado = estadoParqueo[fila][col];

                    switch (estado) {
                        case "L": //Define por default en el mapeado que es L (Libre)
                            // Pedir ID del socio
                            String idSocio = JOptionPane.showInputDialog(this, "Ingrese el ID del socio:");
                            if (idSocio == null || idSocio.trim().isEmpty()) {
                                JOptionPane.showMessageDialog(this, "ID inválido. Intente de nuevo.");
                                return;
                            }

                            // Validar ID en Socio_Registrar
                            boolean idValido = false;
                            for (int i = 0; i < Socio_Registrar.contadorSocios; i++) {
                                if (Socio_Registrar.socios[i][0].equals(idSocio)) {
                                    idValido = true;
                                    break;
                                }
                            }

                            if (!idValido) { //Verifica que el ID exista 
                                JOptionPane.showMessageDialog(this, "ID no registrado. Por favor, registre al socio primero.");
                                return;
                            }

                            estadoParqueo[fila][col] = "O"; //Cambia el mapeo a o "Ocupado"
                            boton.setText("O");
                            boton.setBackground(null);
                            parqueoIDs[fila][col] = idSocio;
                            JOptionPane.showMessageDialog(this, "Espacio registrado con éxito."); //Imprime en pantalla que el método funcionó con exito
                            espacioSeleccionado = true;
                            break;

                        case "O":
                            JOptionPane.showMessageDialog(this, "Espacio ya ocupado. Intente con otro."); //En caso de que el mapeo ya tenga una O, imprime en pantalla:
                            espacioSeleccionado = true;
                            break;

                        case "D":
                            JOptionPane.showMessageDialog(this, "Espacio reservado para discapacitados."); //Mapeo con D significa campo de discapacitado, no se puede reservar por default
                            espacioSeleccionado = true;
                            break;

                        case "E": //En caso de que quiera reservar una E en el mapeo, requiere contraseña
                            String contrasena = JOptionPane.showInputDialog(this, "Espacio reservado para entrenador.\nIngrese la contraseña:");
                            if ("Fide1".equals(contrasena)) {
                                estadoParqueo[fila][col] = "O";
                                boton.setText("O");
                                boton.setBackground(null);
                                JOptionPane.showMessageDialog(this, "Espacio registrado con éxito.");
                            } else {
                                JOptionPane.showMessageDialog(this, "Contraseña incorrecta. Intente de nuevo.");
                            }
                            espacioSeleccionado = true;
                            break;
                    }
                }
            }
        }

        if (!espacioSeleccionado) { //En caso de que presione registrar, imprime:
            JOptionPane.showMessageDialog(this, "Seleccione un espacio antes de registrar.");
        }

    }

    private void liberarEspacio() {
        boolean espacioSeleccionado = false;

        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                JButton boton = matrizBotones[fila][col];

                if (boton.getBackground() != null && boton.getBackground().equals(Color.CYAN)) { //Cambia el color en el mapeo
                    String estado = estadoParqueo[fila][col];

                    if ("O".equals(estado)) {
                        // Restaura al estado original
                        String estadoInicial = estadoOriginal[fila][col];
                        estadoParqueo[fila][col] = estadoInicial;
                        boton.setText(estadoInicial);
                        boton.setBackground(null);
                        JOptionPane.showMessageDialog(this, "Espacio liberado con éxito.");
                    } else {
                        JOptionPane.showMessageDialog(this, "Este espacio no está ocupado.");
                    }

                    espacioSeleccionado = true;
                }
            }
        }

        if (!espacioSeleccionado) {
            JOptionPane.showMessageDialog(this, "Seleccione un espacio para liberar.");
        }
    }

    private void configurarAccionesBotones() {
        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                int f = fila;
                int c = col;
                matrizBotones[fila][col].addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent evt) {
                        // Deseleccionar todos
                        for (int i = 0; i < matrizBotones.length; i++) {
                            for (int j = 0; j < matrizBotones[0].length; j++) {
                                matrizBotones[i][j].setBackground(null);
                            }
                        }
                        // Seleccionar el actual
                        matrizBotones[f][c].setBackground(Color.CYAN);
                    }
                });
            }
        }
    }

    private void mostrarInformacionEspacio() {
        boolean espacioSeleccionado = false;

        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                JButton boton = matrizBotones[fila][col];

                if (boton.getBackground() != null && boton.getBackground().equals(Color.CYAN)) {
                    espacioSeleccionado = true;
                    String estado = estadoParqueo[fila][col];

                    switch (estado) {
                        case "L":
                            JOptionPane.showMessageDialog(this, "Este espacio está libre.");
                            break;
                        case "D":
                            JOptionPane.showMessageDialog(this, "Este espacio está reservado para personas con discapacidad.");
                            break;
                        case "E":
                            JOptionPane.showMessageDialog(this, "Este espacio está reservado para entrenadores.");
                            break;
                        case "O":
                            String id = parqueoIDs[fila][col];
                            String nombre = buscarNombrePorID(id);
                            JOptionPane.showMessageDialog(this, "Este espacio está ocupado por:\nID: " + id + "\nNombre: " + nombre);
                            break;
                        default:
                            JOptionPane.showMessageDialog(this, "Estado desconocido.");
                    }
                    return; // salir después de mostrar info del botón seleccionado
                }
            }
        }

        if (!espacioSeleccionado) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un espacio primero.");
        }
    }

    private String buscarNombrePorID(String idBuscado) {
        for (int i = 0; i < Socio_Registrar.contadorSocios; i++) {
            if (Socio_Registrar.socios[i][0].equals(idBuscado)) {
                return Socio_Registrar.socios[i][1]; // Posición 1 = nombre
            }
        }
        return "Desconocido";
    }

    // -
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pn_principal = new javax.swing.JPanel();
        Img_logo = new javax.swing.JLabel();
        btn_g3 = new javax.swing.JButton();
        btn_g1 = new javax.swing.JButton();
        btn_g2 = new javax.swing.JButton();
        btn_1_2 = new javax.swing.JButton();
        btn_1_1 = new javax.swing.JButton();
        btn_1_5 = new javax.swing.JButton();
        btn_1_3 = new javax.swing.JButton();
        btn_1_4 = new javax.swing.JButton();
        btn_2_2 = new javax.swing.JButton();
        btn_2_3 = new javax.swing.JButton();
        btn_2_4 = new javax.swing.JButton();
        btn_2_5 = new javax.swing.JButton();
        btn_3_4 = new javax.swing.JButton();
        btn_2_1 = new javax.swing.JButton();
        btn_3_3 = new javax.swing.JButton();
        btn_3_5 = new javax.swing.JButton();
        btn_3_1 = new javax.swing.JButton();
        btn_3_2 = new javax.swing.JButton();
        btn_4_3 = new javax.swing.JButton();
        btn_4_2 = new javax.swing.JButton();
        btn_4_4 = new javax.swing.JButton();
        btn_4_5 = new javax.swing.JButton();
        btn_4_1 = new javax.swing.JButton();
        btn_Pliberar = new javax.swing.JButton();
        btn_Pregistro = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_PInfo = new javax.swing.JButton();
        pn_secundario8 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        btn_socio8 = new javax.swing.JButton();
        btn_parqueo8 = new javax.swing.JButton();
        btn_pesas8 = new javax.swing.JButton();
        btn_cabinaAction8 = new javax.swing.JButton();
        btn_recreacion8 = new javax.swing.JButton();
        btn_auditorio8 = new javax.swing.JButton();
        btn_clasesGrupales7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setResizable(false);

        pn_principal.setBackground(new java.awt.Color(255, 255, 255));

        Img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iñasfit logo.jpg"))); // NOI18N
        Img_logo.setText("jLabel2");
        Img_logo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Img_logo.setIconTextGap(0);

        btn_g3.setBackground(new java.awt.Color(0, 204, 204));
        btn_g3.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_g3.setForeground(new java.awt.Color(255, 255, 255));
        btn_g3.setText("G3");
        btn_g3.setToolTipText("");
        btn_g3.setActionCommand("btn_informacionS");
        btn_g3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_g3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_g3btn_pesasActionPerformed(evt);
            }
        });

        btn_g1.setBackground(new java.awt.Color(0, 204, 204));
        btn_g1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_g1.setForeground(new java.awt.Color(255, 255, 255));
        btn_g1.setText("G1");
        btn_g1.setActionCommand("btn_registrarS");
        btn_g1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_g1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_g1btn_pesasActionPerformed(evt);
            }
        });

        btn_g2.setBackground(new java.awt.Color(0, 204, 204));
        btn_g2.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_g2.setForeground(new java.awt.Color(255, 255, 255));
        btn_g2.setText("G2");
        btn_g2.setActionCommand("btn_eliminarS");
        btn_g2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_g2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_g2btn_pesasActionPerformed(evt);
            }
        });

        btn_1_2.setText("L");
        btn_1_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_1_1.setText("D");
        btn_1_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btn_1_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1_1ActionPerformed(evt);
            }
        });

        btn_1_5.setText("E");
        btn_1_5.setActionCommand("L");
        btn_1_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_1_3.setText("L");
        btn_1_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_1_4.setText("L");
        btn_1_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_2.setText("L");
        btn_2_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_3.setText("L");
        btn_2_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_4.setText("L");
        btn_2_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_5.setText("L");
        btn_2_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_4.setText("L");
        btn_3_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_1.setText("D");
        btn_2_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_3.setText("L");
        btn_3_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_5.setText("L");
        btn_3_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_1.setText("D");
        btn_3_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_2.setText("L");
        btn_3_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_3.setText("L");
        btn_4_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_2.setText("L");
        btn_4_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_4.setText("L");
        btn_4_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_5.setText("E");
        btn_4_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_1.setText("D");
        btn_4_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_Pliberar.setBackground(new java.awt.Color(0, 204, 204));
        btn_Pliberar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_Pliberar.setForeground(new java.awt.Color(255, 255, 255));
        btn_Pliberar.setText("Liberar");
        btn_Pliberar.setActionCommand("btn_Pliberar");
        btn_Pliberar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_Pliberar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Pliberarbtn_pesasActionPerformed(evt);
            }
        });

        btn_Pregistro.setBackground(new java.awt.Color(0, 204, 204));
        btn_Pregistro.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_Pregistro.setForeground(new java.awt.Color(255, 255, 255));
        btn_Pregistro.setText("Registrar");
        btn_Pregistro.setActionCommand("btn_registrarS");
        btn_Pregistro.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_Pregistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Pregistrobtn_pesasActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("L-Liberar");

        jLabel2.setBackground(new java.awt.Color(153, 153, 153));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("O-Ocupado");

        jLabel3.setBackground(new java.awt.Color(153, 153, 153));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("E-Entrenador");

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("D-Discapacitado");

        btn_PInfo.setBackground(new java.awt.Color(0, 204, 204));
        btn_PInfo.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_PInfo.setForeground(new java.awt.Color(255, 255, 255));
        btn_PInfo.setText("Informacion");
        btn_PInfo.setActionCommand("btn_Pliberar");
        btn_PInfo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_PInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_PInfobtn_pesasActionPerformed(evt);
            }
        });

        pn_secundario8.setBackground(new java.awt.Color(0, 204, 204));
        pn_secundario8.setForeground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("Administración  Gimnasio");

        btn_socio8.setBackground(new java.awt.Color(0, 204, 204));
        btn_socio8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_socio8.setForeground(new java.awt.Color(255, 255, 255));
        btn_socio8.setText("Socio");
        btn_socio8.setActionCommand("btn_socio");
        btn_socio8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_socio8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_socio8ActionPerformed(evt);
            }
        });

        btn_parqueo8.setBackground(new java.awt.Color(0, 204, 204));
        btn_parqueo8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_parqueo8.setForeground(new java.awt.Color(255, 255, 255));
        btn_parqueo8.setText("Parqueo");
        btn_parqueo8.setActionCommand("btn_parqueo");
        btn_parqueo8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_parqueo8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_parqueo8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_parqueo8ActionPerformed(evt);
            }
        });

        btn_pesas8.setBackground(new java.awt.Color(0, 204, 204));
        btn_pesas8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_pesas8.setForeground(new java.awt.Color(255, 255, 255));
        btn_pesas8.setText("Sala de pesas");
        btn_pesas8.setActionCommand("btn_pesas");
        btn_pesas8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_pesas8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_pesas8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pesas8ActionPerformed(evt);
            }
        });

        btn_cabinaAction8.setBackground(new java.awt.Color(0, 204, 204));
        btn_cabinaAction8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cabinaAction8.setForeground(new java.awt.Color(255, 255, 255));
        btn_cabinaAction8.setText("Cabinas");
        btn_cabinaAction8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cabinaAction8.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction8.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_cabinaAction8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cabinaAction8ActionPerformed(evt);
            }
        });

        btn_recreacion8.setBackground(new java.awt.Color(0, 204, 204));
        btn_recreacion8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_recreacion8.setForeground(new java.awt.Color(255, 255, 255));
        btn_recreacion8.setText("Recreación");
        btn_recreacion8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_recreacion8.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_recreacion8.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_recreacion8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_recreacion8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_recreacion8ActionPerformed(evt);
            }
        });

        btn_auditorio8.setBackground(new java.awt.Color(0, 204, 204));
        btn_auditorio8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_auditorio8.setForeground(new java.awt.Color(255, 255, 255));
        btn_auditorio8.setText("Auditorio");
        btn_auditorio8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_auditorio8.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_auditorio8.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_auditorio8.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_auditorio8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_auditorio8ActionPerformed(evt);
            }
        });

        btn_clasesGrupales7.setBackground(new java.awt.Color(0, 204, 204));
        btn_clasesGrupales7.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_clasesGrupales7.setForeground(new java.awt.Color(255, 255, 255));
        btn_clasesGrupales7.setText("Clases Grupales");
        btn_clasesGrupales7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_clasesGrupales7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clasesGrupales7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_secundario8Layout = new javax.swing.GroupLayout(pn_secundario8);
        pn_secundario8.setLayout(pn_secundario8Layout);
        pn_secundario8Layout.setHorizontalGroup(
            pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario8Layout.createSequentialGroup()
                .addGroup(pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_secundario8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE))
                    .addGroup(pn_secundario8Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btn_cabinaAction8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_socio8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_parqueo8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_clasesGrupales7, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE))
                            .addComponent(btn_pesas8, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_recreacion8, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_auditorio8, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pn_secundario8Layout.setVerticalGroup(
            pn_secundario8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_socio8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_parqueo8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_clasesGrupales7, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_pesas8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_cabinaAction8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_recreacion8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_auditorio8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pn_principalLayout = new javax.swing.GroupLayout(pn_principal);
        pn_principal.setLayout(pn_principalLayout);
        pn_principalLayout.setHorizontalGroup(
            pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_principalLayout.createSequentialGroup()
                .addComponent(pn_secundario8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addComponent(btn_g1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_g2, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_g3, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btn_1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_2_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_3_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_4_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addGap(65, 65, 65)
                                .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addGap(109, 109, 109)
                                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel3)))))
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addGap(216, 216, 216)
                        .addComponent(btn_Pliberar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_PInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
            .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pn_principalLayout.createSequentialGroup()
                    .addGap(216, 216, 216)
                    .addComponent(btn_Pregistro, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(660, Short.MAX_VALUE)))
        );
        pn_principalLayout.setVerticalGroup(
            pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_principalLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_g1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_g2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_g3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(76, 76, 76)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_2_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_3_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_4_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Pliberar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_PInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
            .addGroup(pn_principalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addComponent(jLabel2)
                .addGap(49, 49, 49)
                .addComponent(jLabel5)
                .addGap(43, 43, 43)
                .addComponent(jLabel3)
                .addGap(153, 153, 153))
            .addComponent(pn_secundario8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_principalLayout.createSequentialGroup()
                    .addContainerGap(438, Short.MAX_VALUE)
                    .addComponent(btn_Pregistro, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(43, 43, 43)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pn_principal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_principal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_g3btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_g3btn_pesasActionPerformed
        // TODO add your handling code here:
         Parqueo_G3 parqueo = new Parqueo_G3();

        parqueo.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_btn_g3btn_pesasActionPerformed

    private void btn_g1btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_g1btn_pesasActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_btn_g1btn_pesasActionPerformed

    private void btn_g2btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_g2btn_pesasActionPerformed
        // TODO add your handling code here:
         Parqueo_G2 parqueo = new Parqueo_G2();

        parqueo.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_btn_g2btn_pesasActionPerformed

    private void btn_Pliberarbtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Pliberarbtn_pesasActionPerformed
        // TODO add your handling code here:
        liberarEspacio();

    }//GEN-LAST:event_btn_Pliberarbtn_pesasActionPerformed

    private void btn_Pregistrobtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Pregistrobtn_pesasActionPerformed
        // TODO add your handling code here:
        registrarOcupacion();
    }//GEN-LAST:event_btn_Pregistrobtn_pesasActionPerformed

    private void btn_1_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1_1ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_btn_1_1ActionPerformed

    private void btn_PInfobtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_PInfobtn_pesasActionPerformed
        // TODO add your handling code here:
        mostrarInformacionEspacio();

    }//GEN-LAST:event_btn_PInfobtn_pesasActionPerformed

    private void btn_socio8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_socio8ActionPerformed
        // TODO add your handling code here:
        Socio socio = new Socio();

        socio.setVisible(true); //Activa la interfaz socio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_socio8ActionPerformed

    private void btn_parqueo8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_parqueo8ActionPerformed
        // TODO add your handling code here:
        Parqueo parqueo = new Parqueo();

        parqueo.setVisible(true); //Activa la interfaz Parqueo
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_parqueo8ActionPerformed

    private void btn_pesas8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pesas8ActionPerformed
        // TODO add your handling code here:
        Sala_Pesas sala_pesas = new Sala_Pesas();

        sala_pesas.setVisible(true); //Activa la interfaz sala de pesas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_pesas8ActionPerformed

    private void btn_cabinaAction8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cabinaAction8ActionPerformed
        Cabina cabinas = new Cabina();

        cabinas.setVisible(true); //Activa la interfaz de cabinas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_cabinaAction8ActionPerformed

    private void btn_recreacion8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_recreacion8ActionPerformed
        // TODO add your handling code here:
        Recreacion recreacion = new Recreacion();

        recreacion.setVisible(true); //Activa la interfaz de recreación
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_recreacion8ActionPerformed

    private void btn_auditorio8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_auditorio8ActionPerformed
        Auditorio auditorio = new Auditorio();

        auditorio.setVisible(true); //Activa la interfaz de auditorio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_auditorio8ActionPerformed

    private void btn_clasesGrupales7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clasesGrupales7ActionPerformed
        // TODO add your handling code here:
        ClaseGrupal claseGrupal = new ClaseGrupal();

        claseGrupal.setVisible(true); //Activa la interfaz de ClaseGrupal
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_clasesGrupales7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Parqueo_G1().setVisible(true);
            }
        });
    }

    private void escalarLogo() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/iñasfit logo.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                Img_logo.getWidth(),
                Img_logo.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        Img_logo.setIcon(new ImageIcon(imagenEscalada));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Img_logo;
    private javax.swing.JButton btn_1_1;
    private javax.swing.JButton btn_1_2;
    private javax.swing.JButton btn_1_3;
    private javax.swing.JButton btn_1_4;
    private javax.swing.JButton btn_1_5;
    private javax.swing.JButton btn_2_1;
    private javax.swing.JButton btn_2_2;
    private javax.swing.JButton btn_2_3;
    private javax.swing.JButton btn_2_4;
    private javax.swing.JButton btn_2_5;
    private javax.swing.JButton btn_3_1;
    private javax.swing.JButton btn_3_2;
    private javax.swing.JButton btn_3_3;
    private javax.swing.JButton btn_3_4;
    private javax.swing.JButton btn_3_5;
    private javax.swing.JButton btn_4_1;
    private javax.swing.JButton btn_4_2;
    private javax.swing.JButton btn_4_3;
    private javax.swing.JButton btn_4_4;
    private javax.swing.JButton btn_4_5;
    private javax.swing.JButton btn_PInfo;
    private javax.swing.JButton btn_Pliberar;
    private javax.swing.JButton btn_Pregistro;
    private javax.swing.JButton btn_auditorio8;
    private javax.swing.JButton btn_cabinaAction8;
    private javax.swing.JButton btn_clasesGrupales7;
    private javax.swing.JButton btn_g1;
    private javax.swing.JButton btn_g2;
    private javax.swing.JButton btn_g3;
    private javax.swing.JButton btn_parqueo8;
    private javax.swing.JButton btn_pesas8;
    private javax.swing.JButton btn_recreacion8;
    private javax.swing.JButton btn_socio8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel pn_principal;
    private javax.swing.JPanel pn_secundario8;
    // End of variables declaration//GEN-END:variables
}
