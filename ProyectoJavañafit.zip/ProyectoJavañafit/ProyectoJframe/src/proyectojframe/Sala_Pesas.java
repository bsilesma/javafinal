/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectojframe;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author pipe-
 */
public class Sala_Pesas extends javax.swing.JFrame {

    /**
     * Creates new form Sala_Pesas
     */
    public static String[] salaPesas = new String[100];
    public static String[] salaCardio = new String[100];
    public String tipoSalaSeleccionada = ""; // guarda la selección actual

    public Sala_Pesas() {
        initComponents();
        escalarLogo();
        escalarLogo2();
        btn_spesas.addActionListener(e -> {
            tipoSalaSeleccionada = "pesas";
            btn_spesas.setBackground(new java.awt.Color(0, 153, 255)); // azul activo
            btn_scardio.setBackground(new java.awt.Color(51, 51, 51)); // gris oscuro
        });

        btn_scardio.addActionListener(e -> {
            tipoSalaSeleccionada = "cardio";
            btn_scardio.setBackground(new java.awt.Color(0, 153, 255)); // azul activo
            btn_spesas.setBackground(new java.awt.Color(51, 51, 51)); // gris oscuro
        });
           // efecto hover btns
        btn_socio.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_socio.setBackground(new java.awt.Color(0, 153, 255)); // color al pasar el mouse
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_parqueo.setBackground(new java.awt.Color(0, 204, 204)); // color original
            }
        });

        btn_parqueo.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_parqueo.setBackground(new java.awt.Color(0, 153, 255)); // color al pasar el mouse
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_parqueo.setBackground(new java.awt.Color(0, 204, 204)); // color original
            }
        });
        btn_pesas.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_pesas.setBackground(new java.awt.Color(0, 153, 255)); // color al pasar el mouse
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_pesas.setBackground(new java.awt.Color(0, 204, 204)); // color original
            }
        });

    }

    public String buscarNombreSocio(String id) {
        for (int i = 0; i < Socio_Registrar.contadorSocios; i++) {
            if (Socio_Registrar.socios[i][0].equals(id)) {
                return Socio_Registrar.socios[i][1];
            }
        }
        return "No registrado";
    }

    public boolean socioYaRegistrado(String id) {
        for (int i = 0; i < 100; i++) {
            if ((salaPesas[i] != null && salaPesas[i].equals(id))
                    || (salaCardio[i] != null && salaCardio[i].equals(id))) {
                return true;
            }
        }
        return false;
    }

    public String registrarEnSala(String tipoSala, String id) {
        String[] sala = tipoSala.equals("pesas") ? salaPesas : salaCardio;
        for (int i = 0; i < sala.length; i++) {
            if (sala[i] == null) {
                sala[i] = id;
                return "Socio registrado exitosamente en sala de " + tipoSala + ".";
            }
        }
        return "No hay espacios disponibles en sala de " + tipoSala + ".";
    }

    public String cancelarReserva(String tipoSala, String id) {
        String[] sala = tipoSala.equals("pesas") ? salaPesas : salaCardio;
        for (int i = 0; i < sala.length; i++) {
            if (sala[i] != null && sala[i].equals(id)) {
                sala[i] = null;
                return "Reserva cancelada correctamente.";
            }
        }
        return "No se encontró el socio en la sala de " + tipoSala + ".";
    }

    public String mostrarSocios(String tipoSala) {
        String[] sala = tipoSala.equals("pesas") ? salaPesas : salaCardio;
        StringBuilder sb = new StringBuilder();
        sb.append("Socios en sala de ").append(tipoSala).append(":\n\n");

        for (int i = 0; i < sala.length; i++) {
            if (sala[i] != null) {
                String nombre = buscarNombreSocio(sala[i]);
                sb.append("- ID: ").append(sala[i])
                        .append(" | Nombre: ").append(nombre).append("\n");
            }
        }

        if (sb.toString().trim().equals("Socios en sala de " + tipoSala + ":")) {
            return "No hay socios registrados en la sala de " + tipoSala + ".";
        }

        return sb.toString();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pn_principal = new javax.swing.JPanel();
        Img_logo = new javax.swing.JLabel();
        btn_spesas = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        IMG_CARDIO = new javax.swing.JLabel();
        btn_scardio = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btn_registrarSALA = new javax.swing.JButton();
        btn_informacionSALA = new javax.swing.JButton();
        btn_cancelarSALA = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pn_secundario2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        btn_socio = new javax.swing.JButton();
        btn_parqueo = new javax.swing.JButton();
        btn_pesas = new javax.swing.JButton();
        btn_cabinaAction = new javax.swing.JButton();
        btn_recreacion = new javax.swing.JButton();
        btn_auditorio = new javax.swing.JButton();
        btn_clasesGrupales8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pn_principal.setBackground(new java.awt.Color(255, 255, 255));

        Img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iñasfit logo.jpg"))); // NOI18N
        Img_logo.setText("jLabel2");
        Img_logo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Img_logo.setIconTextGap(0);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pesas.jpeg"))); // NOI18N

        IMG_CARDIO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cardio.jpg"))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setText("Sala Cardio");

        btn_registrarSALA.setBackground(new java.awt.Color(0, 204, 204));
        btn_registrarSALA.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_registrarSALA.setForeground(new java.awt.Color(255, 255, 255));
        btn_registrarSALA.setText("Registrar");
        btn_registrarSALA.setActionCommand("btn_registrarS");
        btn_registrarSALA.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_registrarSALA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarSALAbtn_pesasActionPerformed(evt);
            }
        });

        btn_informacionSALA.setBackground(new java.awt.Color(0, 204, 204));
        btn_informacionSALA.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_informacionSALA.setForeground(new java.awt.Color(255, 255, 255));
        btn_informacionSALA.setText("Informacion");
        btn_informacionSALA.setActionCommand("btn_registrarS");
        btn_informacionSALA.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_informacionSALA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_informacionSALAbtn_pesasActionPerformed(evt);
            }
        });

        btn_cancelarSALA.setBackground(new java.awt.Color(0, 204, 204));
        btn_cancelarSALA.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cancelarSALA.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancelarSALA.setText("Cancelar");
        btn_cancelarSALA.setActionCommand("btn_registrarS");
        btn_cancelarSALA.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cancelarSALA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarSALAbtn_pesasActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setText("Registro de Salas");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel5.setText("Sala maquinas");

        pn_secundario2.setBackground(new java.awt.Color(0, 204, 204));
        pn_secundario2.setForeground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setText("Administración  Gimnasio");

        btn_socio.setBackground(new java.awt.Color(0, 204, 204));
        btn_socio.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_socio.setForeground(new java.awt.Color(255, 255, 255));
        btn_socio.setText("Socio");
        btn_socio.setActionCommand("btn_socio");
        btn_socio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_socio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_socioActionPerformed(evt);
            }
        });

        btn_parqueo.setBackground(new java.awt.Color(0, 204, 204));
        btn_parqueo.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_parqueo.setForeground(new java.awt.Color(255, 255, 255));
        btn_parqueo.setText("Parqueo");
        btn_parqueo.setActionCommand("btn_parqueo");
        btn_parqueo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_parqueo.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_parqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_parqueoActionPerformed(evt);
            }
        });

        btn_pesas.setBackground(new java.awt.Color(0, 204, 204));
        btn_pesas.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_pesas.setForeground(new java.awt.Color(255, 255, 255));
        btn_pesas.setText("Sala de pesas");
        btn_pesas.setActionCommand("btn_pesas");
        btn_pesas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_pesas.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_pesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pesasActionPerformed(evt);
            }
        });

        btn_cabinaAction.setBackground(new java.awt.Color(0, 204, 204));
        btn_cabinaAction.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cabinaAction.setForeground(new java.awt.Color(255, 255, 255));
        btn_cabinaAction.setText("Cabinas");
        btn_cabinaAction.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cabinaAction.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_cabinaAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cabinaActionActionPerformed(evt);
            }
        });

        btn_recreacion.setBackground(new java.awt.Color(0, 204, 204));
        btn_recreacion.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_recreacion.setForeground(new java.awt.Color(255, 255, 255));
        btn_recreacion.setText("Recreación");
        btn_recreacion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_recreacion.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_recreacion.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_recreacion.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_recreacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_recreacionActionPerformed(evt);
            }
        });

        btn_auditorio.setBackground(new java.awt.Color(0, 204, 204));
        btn_auditorio.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_auditorio.setForeground(new java.awt.Color(255, 255, 255));
        btn_auditorio.setText("Auditorio");
        btn_auditorio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_auditorio.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_auditorio.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_auditorio.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_auditorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_auditorioActionPerformed(evt);
            }
        });

        btn_clasesGrupales8.setBackground(new java.awt.Color(0, 204, 204));
        btn_clasesGrupales8.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_clasesGrupales8.setForeground(new java.awt.Color(255, 255, 255));
        btn_clasesGrupales8.setText("Clases Grupales");
        btn_clasesGrupales8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_clasesGrupales8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clasesGrupales8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_secundario2Layout = new javax.swing.GroupLayout(pn_secundario2);
        pn_secundario2.setLayout(pn_secundario2Layout);
        pn_secundario2Layout.setHorizontalGroup(
            pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btn_cabinaAction, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_socio, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_parqueo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_clasesGrupales8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE)
                    .addComponent(btn_pesas, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_recreacion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_auditorio, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        pn_secundario2Layout.setVerticalGroup(
            pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_socio, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_parqueo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_clasesGrupales8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_pesas, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_cabinaAction, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_recreacion, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_auditorio, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pn_principalLayout = new javax.swing.GroupLayout(pn_principal);
        pn_principal.setLayout(pn_principalLayout);
        pn_principalLayout.setHorizontalGroup(
            pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_principalLayout.createSequentialGroup()
                .addComponent(pn_secundario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 102, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(77, 77, 77))
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_spesas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(72, 72, 72)
                                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_scardio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(IMG_CARDIO, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addComponent(btn_registrarSALA, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(46, 46, 46)
                                .addComponent(btn_informacionSALA, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_cancelarSALA, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_principalLayout.createSequentialGroup()
                    .addContainerGap(424, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(395, 395, 395)))
        );
        pn_principalLayout.setVerticalGroup(
            pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_principalLayout.createSequentialGroup()
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_principalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(IMG_CARDIO, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_spesas, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_scardio, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_registrarSALA, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_informacionSALA, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_cancelarSALA, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(92, Short.MAX_VALUE))
            .addComponent(pn_secundario2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pn_principalLayout.createSequentialGroup()
                    .addGap(53, 53, 53)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(391, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_principal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_principal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_cancelarSALAbtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarSALAbtn_pesasActionPerformed
        // TODO add your handling code here:
        String id = JOptionPane.showInputDialog("Ingrese el ID del socio a cancelar:");

        if (id == null || id.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un ID.");
            return;
        }

        if (tipoSalaSeleccionada.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione una sala primero.");
            return;
        }

        String mensaje = cancelarReserva(tipoSalaSeleccionada, id);
        JOptionPane.showMessageDialog(null, mensaje);
    }//GEN-LAST:event_btn_cancelarSALAbtn_pesasActionPerformed

    private void btn_informacionSALAbtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_informacionSALAbtn_pesasActionPerformed
        // TODO add your handling code here:
        if (tipoSalaSeleccionada.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione una sala primero.");
            return;
        }

        String mensaje = mostrarSocios(tipoSalaSeleccionada);
        JOptionPane.showMessageDialog(null, mensaje);
    }//GEN-LAST:event_btn_informacionSALAbtn_pesasActionPerformed

    private void btn_registrarSALAbtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarSALAbtn_pesasActionPerformed
        // TODO add your handling code here:

        String id = JOptionPane.showInputDialog("Ingrese el ID del socio:");

        if (id == null || id.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un ID.");
            return;
        }

        if (tipoSalaSeleccionada.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione una sala primero.");
            return;
        }

        if (buscarNombreSocio(id).equals("No registrado")) {
            JOptionPane.showMessageDialog(null, "El socio no existe.");
            return;
        }

        if (socioYaRegistrado(id)) {
            JOptionPane.showMessageDialog(null, "El socio ya está registrado en otra sala.");
            return;
        }

        String mensaje = registrarEnSala(tipoSalaSeleccionada, id);
        JOptionPane.showMessageDialog(null, mensaje);
    }//GEN-LAST:event_btn_registrarSALAbtn_pesasActionPerformed

    private void btn_socioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_socioActionPerformed
        // TODO add your handling code here:
        Socio socio = new Socio();

        socio.setVisible(true); //Activa la interfaz socio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_socioActionPerformed

    private void btn_parqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_parqueoActionPerformed
        // TODO add your handling code here:
        Parqueo parqueo = new Parqueo();

        parqueo.setVisible(true); //Activa la interfaz Parqueo
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_parqueoActionPerformed

    private void btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pesasActionPerformed
        // TODO add your handling code here:
        Sala_Pesas sala_pesas = new Sala_Pesas();

        sala_pesas.setVisible(true); //Activa la interfaz sala de pesas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_pesasActionPerformed

    private void btn_cabinaActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cabinaActionActionPerformed
        Cabina cabinas = new Cabina();

        cabinas.setVisible(true); //Activa la interfaz de cabinas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_cabinaActionActionPerformed

    private void btn_recreacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_recreacionActionPerformed
        // TODO add your handling code here:
        Recreacion recreacion = new Recreacion();

        recreacion.setVisible(true); //Activa la interfaz de recreación
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_recreacionActionPerformed

    private void btn_auditorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_auditorioActionPerformed
        Auditorio auditorio = new Auditorio();

        auditorio.setVisible(true); //Activa la interfaz de auditorio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_auditorioActionPerformed

    private void btn_clasesGrupales8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clasesGrupales8ActionPerformed
        // TODO add your handling code here:
        ClaseGrupal claseGrupal = new ClaseGrupal();

        claseGrupal.setVisible(true); //Activa la interfaz de ClaseGrupal
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_clasesGrupales8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sala_Pesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sala_Pesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sala_Pesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sala_Pesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sala_Pesas().setVisible(true);
            }
        });
    }

    private void escalarLogo() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/iñasfit logo.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                Img_logo.getWidth(),
                Img_logo.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        Img_logo.setIcon(new ImageIcon(imagenEscalada));

    }

    private void escalarLogo2() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/cardio.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                IMG_CARDIO.getWidth(),
                IMG_CARDIO.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        IMG_CARDIO.setIcon(new ImageIcon(imagenEscalada));

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel IMG_CARDIO;
    private javax.swing.JLabel Img_logo;
    private javax.swing.JButton btn_auditorio;
    private javax.swing.JButton btn_cabinaAction;
    private javax.swing.JButton btn_cancelarSALA;
    private javax.swing.JButton btn_clasesGrupales8;
    private javax.swing.JButton btn_informacionSALA;
    private javax.swing.JButton btn_parqueo;
    private javax.swing.JButton btn_pesas;
    private javax.swing.JButton btn_recreacion;
    private javax.swing.JButton btn_registrarSALA;
    private javax.swing.JButton btn_scardio;
    private javax.swing.JButton btn_socio;
    private javax.swing.JButton btn_spesas;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel pn_principal;
    private javax.swing.JPanel pn_secundario2;
    // End of variables declaration//GEN-END:variables
}
