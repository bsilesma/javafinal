/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectojframe;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author brand
 */
public class ClaseGrupal extends javax.swing.JFrame {
    // ====== Nombres de clases ======
private static String[] nombresClases = {
    "Zumba", "Yoga", "Natación en cemento", "Chisme al fallo"
};


//Contructor
    public ClaseGrupal() {
        initComponents();
        escalarLogo();
        aplicarNombresEnBotones();

    }
    // ================== LÓGICA ==================
    //Metodo1
private void aplicarNombresEnBotones() {
    btn_zumba.setText(nombresClases[0]);
    btn_yoga.setText(nombresClases[1]);
    btn_natación_en_cemento.setText(nombresClases[2]); // ojo: tu variable tiene tilde
    btn_chisme_al_fallo.setText(nombresClases[3]);
}

// BTNACTIONS
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pn_secundario1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btn_socio1 = new javax.swing.JButton();
        btn_parqueo1 = new javax.swing.JButton();
        btn_pesas1 = new javax.swing.JButton();
        btn_cabinaAction1 = new javax.swing.JButton();
        btn_recreacion1 = new javax.swing.JButton();
        btn_auditorio1 = new javax.swing.JButton();
        btn_clasesGrupales1 = new javax.swing.JButton();
        Img_logo = new javax.swing.JLabel();
        txt_bienvenida = new javax.swing.JLabel();
        btn_zumba = new javax.swing.JButton();
        btn_yoga = new javax.swing.JButton();
        btn_natación_en_cemento = new javax.swing.JButton();
        btn_chisme_al_fallo = new javax.swing.JButton();
        btn_cambiarClase = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setFocusable(false);
        jPanel1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N

        pn_secundario1.setBackground(new java.awt.Color(0, 204, 204));
        pn_secundario1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Administración  Gimnasio");

        btn_socio1.setBackground(new java.awt.Color(0, 204, 204));
        btn_socio1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_socio1.setForeground(new java.awt.Color(255, 255, 255));
        btn_socio1.setText("Socio");
        btn_socio1.setActionCommand("btn_socio");
        btn_socio1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_socio1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_socio1ActionPerformed(evt);
            }
        });

        btn_parqueo1.setBackground(new java.awt.Color(0, 204, 204));
        btn_parqueo1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_parqueo1.setForeground(new java.awt.Color(255, 255, 255));
        btn_parqueo1.setText("Parqueo");
        btn_parqueo1.setActionCommand("btn_parqueo");
        btn_parqueo1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_parqueo1.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_parqueo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_parqueo1ActionPerformed(evt);
            }
        });

        btn_pesas1.setBackground(new java.awt.Color(0, 204, 204));
        btn_pesas1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_pesas1.setForeground(new java.awt.Color(255, 255, 255));
        btn_pesas1.setText("Sala de pesas");
        btn_pesas1.setActionCommand("btn_pesas");
        btn_pesas1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_pesas1.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_pesas1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pesas1ActionPerformed(evt);
            }
        });

        btn_cabinaAction1.setBackground(new java.awt.Color(0, 204, 204));
        btn_cabinaAction1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cabinaAction1.setForeground(new java.awt.Color(255, 255, 255));
        btn_cabinaAction1.setText("Cabinas");
        btn_cabinaAction1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cabinaAction1.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction1.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction1.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_cabinaAction1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cabinaAction1ActionPerformed(evt);
            }
        });

        btn_recreacion1.setBackground(new java.awt.Color(0, 204, 204));
        btn_recreacion1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_recreacion1.setForeground(new java.awt.Color(255, 255, 255));
        btn_recreacion1.setText("Recreación");
        btn_recreacion1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_recreacion1.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_recreacion1.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_recreacion1.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_recreacion1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_recreacion1ActionPerformed(evt);
            }
        });

        btn_auditorio1.setBackground(new java.awt.Color(0, 204, 204));
        btn_auditorio1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_auditorio1.setForeground(new java.awt.Color(255, 255, 255));
        btn_auditorio1.setText("Auditorio");
        btn_auditorio1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_auditorio1.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_auditorio1.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_auditorio1.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_auditorio1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_auditorio1ActionPerformed(evt);
            }
        });

        btn_clasesGrupales1.setBackground(new java.awt.Color(0, 204, 204));
        btn_clasesGrupales1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_clasesGrupales1.setForeground(new java.awt.Color(255, 255, 255));
        btn_clasesGrupales1.setText("Clases Grupales");
        btn_clasesGrupales1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_clasesGrupales1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clasesGrupales1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_secundario1Layout = new javax.swing.GroupLayout(pn_secundario1);
        pn_secundario1.setLayout(pn_secundario1Layout);
        pn_secundario1Layout.setHorizontalGroup(
            pn_secundario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario1Layout.createSequentialGroup()
                .addGroup(pn_secundario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_secundario1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pn_secundario1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(pn_secundario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_auditorio1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_recreacion1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pn_secundario1Layout.createSequentialGroup()
                                .addGroup(pn_secundario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_cabinaAction1, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                                    .addComponent(btn_socio1, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                                    .addComponent(btn_parqueo1, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                                    .addComponent(btn_clasesGrupales1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_secundario1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_pesas1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pn_secundario1Layout.setVerticalGroup(
            pn_secundario1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_socio1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_parqueo1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_clasesGrupales1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_pesas1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_cabinaAction1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_recreacion1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_auditorio1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        Img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iñasfit logo.jpg"))); // NOI18N
        Img_logo.setText("jLabel2");
        Img_logo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Img_logo.setIconTextGap(0);

        txt_bienvenida.setBackground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        txt_bienvenida.setForeground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txt_bienvenida.setText("Seleccione la clase");

        btn_zumba.setBackground(new java.awt.Color(0, 204, 204));
        btn_zumba.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_zumba.setForeground(new java.awt.Color(255, 255, 255));
        btn_zumba.setText("Zumba");
        btn_zumba.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_zumba.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_zumbaActionPerformed(evt);
            }
        });

        btn_yoga.setBackground(new java.awt.Color(0, 204, 204));
        btn_yoga.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_yoga.setForeground(new java.awt.Color(255, 255, 255));
        btn_yoga.setText("Yoga");
        btn_yoga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_yoga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_yogaActionPerformed(evt);
            }
        });

        btn_natación_en_cemento.setBackground(new java.awt.Color(0, 204, 204));
        btn_natación_en_cemento.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_natación_en_cemento.setForeground(new java.awt.Color(255, 255, 255));
        btn_natación_en_cemento.setText("Natación en cemento");
        btn_natación_en_cemento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_natación_en_cemento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_natación_en_cementoActionPerformed(evt);
            }
        });

        btn_chisme_al_fallo.setBackground(new java.awt.Color(0, 204, 204));
        btn_chisme_al_fallo.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btn_chisme_al_fallo.setForeground(new java.awt.Color(255, 255, 255));
        btn_chisme_al_fallo.setText("Chisme al fallo");
        btn_chisme_al_fallo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_chisme_al_fallo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_chisme_al_falloActionPerformed(evt);
            }
        });

        btn_cambiarClase.setBackground(new java.awt.Color(0, 204, 204));
        btn_cambiarClase.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cambiarClase.setForeground(new java.awt.Color(255, 255, 255));
        btn_cambiarClase.setText("Cambiar clase");
        btn_cambiarClase.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cambiarClase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cambiarClaseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(pn_secundario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(txt_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 197, Short.MAX_VALUE)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(108, 108, 108)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_natación_en_cemento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_zumba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_chisme_al_fallo, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                    .addComponent(btn_yoga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(226, 226, 226)
                                .addComponent(btn_cambiarClase, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_secundario1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(txt_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_zumba, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_yoga, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_natación_en_cemento, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_chisme_al_fallo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_cambiarClase, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(109, 109, 109))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_chisme_al_falloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_chisme_al_falloActionPerformed
        // TODO add your handling code here:
        Chisme claseChisme = new Chisme();

        claseChisme.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_chisme_al_falloActionPerformed

    private void btn_natación_en_cementoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_natación_en_cementoActionPerformed
        // TODO add your handling code here:
        Natacion claseNatacion = new Natacion();

        claseNatacion.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_natación_en_cementoActionPerformed

    private void btn_yogaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_yogaActionPerformed
        // TODO add your handling code here:
        Yoga claseYoga = new Yoga();

        claseYoga.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_yogaActionPerformed

    private void btn_zumbaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_zumbaActionPerformed
        // TODO add your handling code here:
        Zumba claseZumba = new Zumba();

        claseZumba.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_zumbaActionPerformed

    private void btn_clasesGrupales1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clasesGrupales1ActionPerformed
        // TODO add your handling code here:
        ClaseGrupal claseGrupal = new ClaseGrupal();

        claseGrupal.setVisible(true); //Activa la interfaz de ClaseGrupal
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_clasesGrupales1ActionPerformed

    private void btn_auditorio1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_auditorio1ActionPerformed
        Auditorio auditorio = new Auditorio();

        auditorio.setVisible(true); //Activa la interfaz de auditorio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_auditorio1ActionPerformed

    private void btn_recreacion1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_recreacion1ActionPerformed
        // TODO add your handling code here:
        Recreacion recreacion = new Recreacion();

        recreacion.setVisible(true); //Activa la interfaz de recreación
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_recreacion1ActionPerformed

    private void btn_cabinaAction1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cabinaAction1ActionPerformed
        Cabina cabinas = new Cabina();

        cabinas.setVisible(true); //Activa la interfaz de cabinas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_cabinaAction1ActionPerformed

    private void btn_pesas1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pesas1ActionPerformed
        // TODO add your handling code here:
        Sala_Pesas sala_pesas = new Sala_Pesas();

        sala_pesas.setVisible(true); //Activa la interfaz sala de pesas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_pesas1ActionPerformed

    private void btn_parqueo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_parqueo1ActionPerformed
        // TODO add your handling code here:
        Parqueo parqueo = new Parqueo();

        parqueo.setVisible(true); //Activa la interfaz Parqueo
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_parqueo1ActionPerformed

    private void btn_socio1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_socio1ActionPerformed
        // TODO add your handling code here:
        Socio socio = new Socio();

        socio.setVisible(true); //Activa la interfaz socio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_socio1ActionPerformed

    private void btn_cambiarClaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cambiarClaseActionPerformed
        // TODO add your handling code here:
        String[] opciones = {
        nombresClases[0], nombresClases[1], nombresClases[2], nombresClases[3]
    };
    String seleccion = (String) javax.swing.JOptionPane.showInputDialog(
            this, "¿Cuál clase desea renombrar?", "Cambiar clase",
            javax.swing.JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
    if (seleccion == null) return;

    int idx = -1;
    for (int i = 0; i < nombresClases.length; i++) {
        if (nombresClases[i].equals(seleccion)) { idx = i; break; }
    }
    if (idx == -1) return;

    String nuevo = javax.swing.JOptionPane.showInputDialog(
            this, "Nuevo nombre para \"" + nombresClases[idx] + "\":", nombresClases[idx]);
    if (nuevo == null) return;
    nuevo = nuevo.trim();
    if (nuevo.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío.");
        return;
    }
    for (int i = 0; i < nombresClases.length; i++) {
        if (i != idx && nuevo.equalsIgnoreCase(nombresClases[i])) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ya existe una clase con ese nombre.");
            return;
        }
    }

    nombresClases[idx] = nuevo;      // <-- queda en memoria compartida (estática)
    aplicarNombresEnBotones();       // <-- refresca los textos de los botones
    }//GEN-LAST:event_btn_cambiarClaseActionPerformed
    //Metodo logo 
    private void escalarLogo() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/iñasfit logo.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                Img_logo.getWidth(),
                Img_logo.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        Img_logo.setIcon(new ImageIcon(imagenEscalada));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClaseGrupal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClaseGrupal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClaseGrupal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClaseGrupal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClaseGrupal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Img_logo;
    private javax.swing.JButton btn_auditorio1;
    private javax.swing.JButton btn_cabinaAction1;
    private javax.swing.JButton btn_cambiarClase;
    private javax.swing.JButton btn_chisme_al_fallo;
    private javax.swing.JButton btn_clasesGrupales1;
    private javax.swing.JButton btn_natación_en_cemento;
    private javax.swing.JButton btn_parqueo1;
    private javax.swing.JButton btn_pesas1;
    private javax.swing.JButton btn_recreacion1;
    private javax.swing.JButton btn_socio1;
    private javax.swing.JButton btn_yoga;
    private javax.swing.JButton btn_zumba;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel pn_secundario1;
    private javax.swing.JLabel txt_bienvenida;
    // End of variables declaration//GEN-END:variables
}
