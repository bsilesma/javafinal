/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectojframe;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author brand
 */
public class Natacion extends javax.swing.JFrame {

    /**
     * Creates new form Natacion
     */
    // ====== MODELO (solo arreglos) ======
    private static final int DURACION_MIN = 60; // 1 hora por clase
    private static final int SLOTS = 9;

// Estado (persiste mientras la app esté abierta)
    private static String[] natSocioId = new String[SLOTS]; // ID por slot
    private static long[] natInicio = new long[SLOTS];   // millis inicio

// Selección en UI
    private int slotSeleccionado = -1;

// Para pintar fácil
    private javax.swing.JButton[] btnsSlot;

    public Natacion() {
        initComponents();
        escalarLogo();
        // Mapear los 9 botones en orden
        btnsSlot = new javax.swing.JButton[]{
            btn_9am, btn_10am, btn_11am,
            btn_12pm, btn_1pm, btn_2pm,
            btn_3pm, btn_4pm, btn_5pm
        };

// Pintar estado guardado
        refrescarColores();

    }
    // ================== LÓGICA ==================

    private void seleccionar(int slot) {
        slotSeleccionado = slot;
        refrescarColores();
    }

    private void refrescarColores() {
        java.awt.Color normal = new java.awt.Color(200, 200, 200);
        java.awt.Color reservado = new java.awt.Color(120, 120, 120);
        java.awt.Color seleccionado = new java.awt.Color(0, 153, 255);

        for (int i = 0; i < SLOTS; i++) {
            javax.swing.JButton b = btnsSlot[i];
            boolean ocupado = (natSocioId[i] != null);
            b.setBackground(ocupado ? reservado : normal);
            if (slotSeleccionado == i) {
                b.setBackground(seleccionado);
            }
        }
    }

    private void reservar() {
        if (slotSeleccionado == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
            return;
        }
        if (natSocioId[slotSeleccionado] != null) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ese horario ya está reservado.");
            return;
        }

        String id = javax.swing.JOptionPane.showInputDialog(this, "Digite el ID del socio:");
        if (id == null || id.trim().isEmpty()) {
            return;
        }
        id = id.trim();

        int filaSocio = buscarFilaSocioPorId(id);
        if (filaSocio == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "El ID no existe en Socio_Registrar.");
            return;
        }

        natSocioId[slotSeleccionado] = id;
        natInicio[slotSeleccionado] = System.currentTimeMillis();

        javax.swing.JOptionPane.showMessageDialog(this,
                "Reserva confirmada para: " + Socio_Registrar.socios[filaSocio][1] + " (ID " + id + ").");
        refrescarColores();
    }

    private void verInformacion() {
        if (slotSeleccionado == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
            return;
        }

        String id = natSocioId[slotSeleccionado];
        if (id == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "El horario está libre.");
            return;
        }

        int fila = buscarFilaSocioPorId(id);
        String nombre = (fila >= 0) ? Socio_Registrar.socios[fila][1] : "(desconocido)";

        long ini = natInicio[slotSeleccionado];
        long minPasados = (System.currentTimeMillis() - ini) / 60000;
        long minRest = Math.max(0, DURACION_MIN - minPasados);

        javax.swing.JOptionPane.showMessageDialog(this,
                "Horario: " + btnsSlot[slotSeleccionado].getText()
                + "\nSocio: " + nombre
                + "\nID: " + id
                + "\nMinutos restantes: " + minRest + " min");
    }

    private void liberar() {
        if (slotSeleccionado == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Primero seleccione un horario.");
            return;
        }
        if (natSocioId[slotSeleccionado] == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ese horario ya está libre.");
            return;
        }

        int opt = javax.swing.JOptionPane.showConfirmDialog(this, "¿Cancelar la reservación?", "Confirmar",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (opt != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        natSocioId[slotSeleccionado] = null;
        natInicio[slotSeleccionado] = 0L;

        javax.swing.JOptionPane.showMessageDialog(this, "Reservación liberada.");
        refrescarColores();
    }

// ================== AUXILIARES ==================
    private int buscarFilaSocioPorId(String id) {
        for (int i = 0; i < Socio_Registrar.socios.length; i++) {
            if (Socio_Registrar.socios[i][0] != null && Socio_Registrar.socios[i][0].equals(id)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pn_secundario = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btn_socio = new javax.swing.JButton();
        btn_parqueo = new javax.swing.JButton();
        btn_pesas = new javax.swing.JButton();
        btn_cabinaAction = new javax.swing.JButton();
        btn_recreacion = new javax.swing.JButton();
        btn_auditorio = new javax.swing.JButton();
        btn_clasesGrupales = new javax.swing.JButton();
        Img_logo = new javax.swing.JLabel();
        txt_bienvenida = new javax.swing.JLabel();
        btn_9am = new javax.swing.JButton();
        btn_10am = new javax.swing.JButton();
        btn_11am = new javax.swing.JButton();
        btn_12pm = new javax.swing.JButton();
        btn_1pm = new javax.swing.JButton();
        btn_2pm = new javax.swing.JButton();
        btn_3pm = new javax.swing.JButton();
        btn_4pm = new javax.swing.JButton();
        btn_5pm = new javax.swing.JButton();
        Reservar = new javax.swing.JButton();
        btn_liberar = new javax.swing.JButton();
        btn_Información = new javax.swing.JButton();
        btn_volver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        pn_secundario.setBackground(new java.awt.Color(0, 204, 204));
        pn_secundario.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Administración  Gimnasio");

        btn_socio.setBackground(new java.awt.Color(0, 204, 204));
        btn_socio.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_socio.setForeground(new java.awt.Color(255, 255, 255));
        btn_socio.setText("Socio");
        btn_socio.setActionCommand("btn_socio");
        btn_socio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_socio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_socioActionPerformed(evt);
            }
        });

        btn_parqueo.setBackground(new java.awt.Color(0, 204, 204));
        btn_parqueo.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_parqueo.setForeground(new java.awt.Color(255, 255, 255));
        btn_parqueo.setText("Parqueo");
        btn_parqueo.setActionCommand("btn_parqueo");
        btn_parqueo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_parqueo.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_parqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_parqueoActionPerformed(evt);
            }
        });

        btn_pesas.setBackground(new java.awt.Color(0, 204, 204));
        btn_pesas.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_pesas.setForeground(new java.awt.Color(255, 255, 255));
        btn_pesas.setText("Sala de pesas");
        btn_pesas.setActionCommand("btn_pesas");
        btn_pesas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_pesas.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_pesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pesasActionPerformed(evt);
            }
        });

        btn_cabinaAction.setBackground(new java.awt.Color(0, 204, 204));
        btn_cabinaAction.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cabinaAction.setForeground(new java.awt.Color(255, 255, 255));
        btn_cabinaAction.setText("Cabinas");
        btn_cabinaAction.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cabinaAction.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_cabinaAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cabinaActionActionPerformed(evt);
            }
        });

        btn_recreacion.setBackground(new java.awt.Color(0, 204, 204));
        btn_recreacion.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_recreacion.setForeground(new java.awt.Color(255, 255, 255));
        btn_recreacion.setText("Recreación");
        btn_recreacion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_recreacion.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_recreacion.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_recreacion.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_recreacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_recreacionActionPerformed(evt);
            }
        });

        btn_auditorio.setBackground(new java.awt.Color(0, 204, 204));
        btn_auditorio.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_auditorio.setForeground(new java.awt.Color(255, 255, 255));
        btn_auditorio.setText("Auditorio");
        btn_auditorio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_auditorio.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_auditorio.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_auditorio.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_auditorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_auditorioActionPerformed(evt);
            }
        });

        btn_clasesGrupales.setBackground(new java.awt.Color(0, 204, 204));
        btn_clasesGrupales.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_clasesGrupales.setForeground(new java.awt.Color(255, 255, 255));
        btn_clasesGrupales.setText("Clases Grupales");
        btn_clasesGrupales.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_clasesGrupales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clasesGrupalesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_secundarioLayout = new javax.swing.GroupLayout(pn_secundario);
        pn_secundario.setLayout(pn_secundarioLayout);
        pn_secundarioLayout.setHorizontalGroup(
            pn_secundarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundarioLayout.createSequentialGroup()
                .addGroup(pn_secundarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_secundarioLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pn_secundarioLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(pn_secundarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_auditorio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_recreacion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pn_secundarioLayout.createSequentialGroup()
                                .addGroup(pn_secundarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_cabinaAction, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_socio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_parqueo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_clasesGrupales, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_secundarioLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_pesas, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pn_secundarioLayout.setVerticalGroup(
            pn_secundarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundarioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_socio, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_parqueo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_clasesGrupales, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_pesas, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_cabinaAction, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_recreacion, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_auditorio, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iñasfit logo.jpg"))); // NOI18N
        Img_logo.setText("jLabel2");
        Img_logo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Img_logo.setIconTextGap(0);

        txt_bienvenida.setBackground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txt_bienvenida.setForeground(new java.awt.Color(0, 0, 0));
        txt_bienvenida.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txt_bienvenida.setText("Seleccione el horario");

        btn_9am.setText("9am-10am");
        btn_9am.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_9amActionPerformed(evt);
            }
        });

        btn_10am.setText("10am-11am");
        btn_10am.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_10amActionPerformed(evt);
            }
        });

        btn_11am.setText("11am-12pm");
        btn_11am.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_11amActionPerformed(evt);
            }
        });

        btn_12pm.setText("12pm-1pm");
        btn_12pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_12pmActionPerformed(evt);
            }
        });

        btn_1pm.setText("1pm-2pm");
        btn_1pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1pmActionPerformed(evt);
            }
        });

        btn_2pm.setText("2pm-3pm");
        btn_2pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_2pmActionPerformed(evt);
            }
        });

        btn_3pm.setText("3pm-4pm");
        btn_3pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_3pmActionPerformed(evt);
            }
        });

        btn_4pm.setText("4pm-5pm");
        btn_4pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_4pmActionPerformed(evt);
            }
        });

        btn_5pm.setText("5pm-6pm");
        btn_5pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_5pmActionPerformed(evt);
            }
        });

        Reservar.setBackground(new java.awt.Color(0, 204, 204));
        Reservar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        Reservar.setForeground(new java.awt.Color(255, 255, 255));
        Reservar.setText("Reservar");
        Reservar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        Reservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReservarActionPerformed(evt);
            }
        });

        btn_liberar.setBackground(new java.awt.Color(0, 204, 204));
        btn_liberar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_liberar.setForeground(new java.awt.Color(255, 255, 255));
        btn_liberar.setText("Liberar");
        btn_liberar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_liberar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_liberarActionPerformed(evt);
            }
        });

        btn_Información.setBackground(new java.awt.Color(0, 204, 204));
        btn_Información.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_Información.setForeground(new java.awt.Color(255, 255, 255));
        btn_Información.setText("Información");
        btn_Información.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_Información.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_InformaciónActionPerformed(evt);
            }
        });

        btn_volver.setBackground(new java.awt.Color(0, 204, 204));
        btn_volver.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_volver.setForeground(new java.awt.Color(255, 255, 255));
        btn_volver.setText("Volver");
        btn_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_volverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(pn_secundario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(175, 175, 175)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txt_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(59, 59, 59)
                                .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 170, Short.MAX_VALUE)
                                .addGap(36, 36, 36))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btn_12pm, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_1pm, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(btn_9am, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_10am, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btn_3pm, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_4pm, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_11am, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_2pm, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_5pm, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(Reservar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_liberar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_Información, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_volver, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_secundario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt_bienvenida)
                        .addGap(63, 63, 63)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btn_10am, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btn_11am, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btn_9am, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_12pm, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_1pm, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_2pm, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_3pm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_4pm, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_5pm, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(63, 63, 63)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Reservar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_liberar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Información, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(btn_volver, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_socioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_socioActionPerformed
        // TODO add your handling code here:
        Socio socio = new Socio();

        socio.setVisible(true); //Activa la interfaz socio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_socioActionPerformed

    private void btn_parqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_parqueoActionPerformed
        // TODO add your handling code here:
        Parqueo parqueo = new Parqueo();

        parqueo.setVisible(true); //Activa la interfaz Parqueo
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_parqueoActionPerformed

    private void btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pesasActionPerformed
        // TODO add your handling code here:
        Sala_Pesas sala_pesas = new Sala_Pesas();

        sala_pesas.setVisible(true); //Activa la interfaz sala de pesas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_pesasActionPerformed

    private void btn_cabinaActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cabinaActionActionPerformed
        Cabina cabinas = new Cabina();

        cabinas.setVisible(true); //Activa la interfaz de cabinas
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_cabinaActionActionPerformed

    private void btn_recreacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_recreacionActionPerformed
        // TODO add your handling code here:
        Recreacion recreacion = new Recreacion();

        recreacion.setVisible(true); //Activa la interfaz de recreación
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_recreacionActionPerformed

    private void btn_auditorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_auditorioActionPerformed
        Auditorio auditorio = new Auditorio();

        auditorio.setVisible(true); //Activa la interfaz de auditorio
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_auditorioActionPerformed

    private void btn_clasesGrupalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clasesGrupalesActionPerformed
        // TODO add your handling code here:
        ClaseGrupal claseGrupal = new ClaseGrupal();

        claseGrupal.setVisible(true); //Activa la interfaz de ClaseGrupal
        this.setVisible(false); //Desactiva la actual
    }//GEN-LAST:event_btn_clasesGrupalesActionPerformed

    private void btn_3pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_3pmActionPerformed
        // TODO add your handling code here:
        seleccionar(6);
    }//GEN-LAST:event_btn_3pmActionPerformed

    private void btn_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_volverActionPerformed
        // TODO add your handling code here:
        ClaseGrupal claseGrupal = new ClaseGrupal();

        claseGrupal.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_volverActionPerformed

    private void btn_9amActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_9amActionPerformed
        // TODO add your handling code here:
        seleccionar(0);
    }//GEN-LAST:event_btn_9amActionPerformed

    private void btn_10amActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_10amActionPerformed
        // TODO add your handling code here:
        seleccionar(1);
    }//GEN-LAST:event_btn_10amActionPerformed

    private void btn_11amActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_11amActionPerformed

        seleccionar(2);
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_11amActionPerformed

    private void btn_12pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_12pmActionPerformed
        // TODO add your handling code here:
        seleccionar(3);
    }//GEN-LAST:event_btn_12pmActionPerformed

    private void btn_1pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1pmActionPerformed
        // TODO add your handling code here:
        seleccionar(4);
    }//GEN-LAST:event_btn_1pmActionPerformed

    private void btn_2pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_2pmActionPerformed
        // TODO add your handling code here:
        seleccionar(5);
    }//GEN-LAST:event_btn_2pmActionPerformed

    private void btn_4pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_4pmActionPerformed
        // TODO add your handling code here:
        seleccionar(7);
    }//GEN-LAST:event_btn_4pmActionPerformed

    private void btn_5pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_5pmActionPerformed
        // TODO add your handling code here:
        seleccionar(8);
    }//GEN-LAST:event_btn_5pmActionPerformed

    private void ReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReservarActionPerformed
        // TODO add your handling code here:
        reservar();
    }//GEN-LAST:event_ReservarActionPerformed

    private void btn_liberarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_liberarActionPerformed
        // TODO add your handling code here:
        liberar();
    }//GEN-LAST:event_btn_liberarActionPerformed

    private void btn_InformaciónActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_InformaciónActionPerformed
        // TODO add your handling code here:
        verInformacion();
    }//GEN-LAST:event_btn_InformaciónActionPerformed
    private void escalarLogo() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/iñasfit logo.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                Img_logo.getWidth(),
                Img_logo.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        Img_logo.setIcon(new ImageIcon(imagenEscalada));
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Natacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Natacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Natacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Natacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Natacion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Img_logo;
    private javax.swing.JButton Reservar;
    private javax.swing.JButton btn_10am;
    private javax.swing.JButton btn_11am;
    private javax.swing.JButton btn_12pm;
    private javax.swing.JButton btn_1pm;
    private javax.swing.JButton btn_2pm;
    private javax.swing.JButton btn_3pm;
    private javax.swing.JButton btn_4pm;
    private javax.swing.JButton btn_5pm;
    private javax.swing.JButton btn_9am;
    private javax.swing.JButton btn_Información;
    private javax.swing.JButton btn_auditorio;
    private javax.swing.JButton btn_cabinaAction;
    private javax.swing.JButton btn_clasesGrupales;
    private javax.swing.JButton btn_liberar;
    private javax.swing.JButton btn_parqueo;
    private javax.swing.JButton btn_pesas;
    private javax.swing.JButton btn_recreacion;
    private javax.swing.JButton btn_socio;
    private javax.swing.JButton btn_volver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel pn_secundario;
    private javax.swing.JLabel txt_bienvenida;
    // End of variables declaration//GEN-END:variables
}
