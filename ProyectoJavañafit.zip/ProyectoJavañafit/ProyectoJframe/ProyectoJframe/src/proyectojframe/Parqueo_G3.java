/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectojframe;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author pipe-
 */
public class Parqueo_G3 extends javax.swing.JFrame {
    private JButton[][] matrizBotones = new JButton[6][5]; // 6 filas, 5 columnas

    private static String[][] estadoParqueo = {
        {"D", "L", "L", "L", "E"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "E"},
        {"L", "L", "L", "L", "L"},
        {"L", "L", "L", "L", "L"}
    };
    private static String[][] estadoOriginal = {
        {"D", "L", "L", "L", "E"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "L"},
        {"D", "L", "L", "L", "E"},
         {"L", "L", "L", "L", "L"},
         {"L", "L", "L", "L", "L"}
            
    };
    private static String[][] parqueoIDs = new String[6][5];
    /**
     * Creates new form Parqueo_G3
     */
    public Parqueo_G3() {
        initComponents();
    }
     private void inicializarMatrizBotones() {
        matrizBotones[0][0] = btn_1_1;
        matrizBotones[0][1] = btn_1_2;
        matrizBotones[0][2] = btn_1_3;
        matrizBotones[0][3] = btn_1_4;
        matrizBotones[0][4] = btn_1_5;

        matrizBotones[1][0] = btn_2_1;
        matrizBotones[1][1] = btn_2_2;
        matrizBotones[1][2] = btn_2_3;
        matrizBotones[1][3] = btn_2_4;
        matrizBotones[1][4] = btn_2_5;

        matrizBotones[2][0] = btn_3_1;
        matrizBotones[2][1] = btn_3_2;
        matrizBotones[2][2] = btn_3_3;
        matrizBotones[2][3] = btn_3_4;
        matrizBotones[2][4] = btn_3_5;

        matrizBotones[3][0] = btn_4_1;
        matrizBotones[3][1] = btn_4_2;
        matrizBotones[3][2] = btn_4_3;
        matrizBotones[3][3] = btn_4_4;
        matrizBotones[3][4] = btn_4_5;
        
        matrizBotones[4][0] = btn_5_1;
        matrizBotones[4][1] = btn_5_2;
        matrizBotones[4][2] = btn_5_3;
        matrizBotones[4][3] = btn_5_4;
        matrizBotones[4][4] = btn_5_5;
        
        matrizBotones[5][0] = btn_6_1;
        matrizBotones[5][1] = btn_6_2;
        matrizBotones[5][2] = btn_6_3;
        matrizBotones[5][3] = btn_6_4;
        matrizBotones[5][4] = btn_6_5;

       
    }

    private void actualizarTextoBotones() {
        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                matrizBotones[fila][col].setText(estadoParqueo[fila][col]);
            }
        }
    }

    private void registrarOcupacion() {
        boolean espacioSeleccionado = false;

        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                JButton boton = matrizBotones[fila][col];

                if (boton.getBackground() != null && boton.getBackground().equals(Color.CYAN)) {
                    String estado = estadoParqueo[fila][col];

                    switch (estado) {
                        case "L":
                            // Pedir ID del socio
                            String idSocio = JOptionPane.showInputDialog(this, "Ingrese el ID del socio:");
                            if (idSocio == null || idSocio.trim().isEmpty()) {
                                JOptionPane.showMessageDialog(this, "ID inválido. Intente de nuevo.");
                                return;
                            }

                            // Validar ID en Socio_Registrar
                            boolean idValido = false;
                            for (int i = 0; i < Socio_Registrar.contadorSocios; i++) {
                                if (Socio_Registrar.socios[i][0].equals(idSocio)) {
                                    idValido = true;
                                    break;
                                }
                            }

                            if (!idValido) {
                                JOptionPane.showMessageDialog(this, "ID no registrado. Por favor, registre al socio primero.");
                                return;
                            }

                            estadoParqueo[fila][col] = "O";
                            boton.setText("O");
                            boton.setBackground(null);
                            parqueoIDs[fila][col] = idSocio;
                            JOptionPane.showMessageDialog(this, "Espacio registrado con éxito.");
                            espacioSeleccionado = true;
                            break;

                        case "O":
                            JOptionPane.showMessageDialog(this, "Espacio ya ocupado. Intente con otro.");
                            espacioSeleccionado = true;
                            break;

                        case "D":
                            JOptionPane.showMessageDialog(this, "Espacio reservado para discapacitados.");
                            espacioSeleccionado = true;
                            break;

                        case "E":
                            String contrasena = JOptionPane.showInputDialog(this, "Espacio reservado para entrenador.\nIngrese la contraseña:");
                            if ("Fide1".equals(contrasena)) {
                                estadoParqueo[fila][col] = "O";
                                boton.setText("O");
                                boton.setBackground(null);
                                JOptionPane.showMessageDialog(this, "Espacio registrado con éxito.");
                            } else {
                                JOptionPane.showMessageDialog(this, "Contraseña incorrecta. Intente de nuevo.");
                            }
                            espacioSeleccionado = true;
                            break;
                    }
                }
            }
        }

        if (!espacioSeleccionado) {
            JOptionPane.showMessageDialog(this, "Seleccione un espacio antes de registrar.");
        }

    }

    private void liberarEspacio() {
        boolean espacioSeleccionado = false;

        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                JButton boton = matrizBotones[fila][col];

                if (boton.getBackground() != null && boton.getBackground().equals(Color.CYAN)) {
                    String estado = estadoParqueo[fila][col];

                    if ("O".equals(estado)) {
                        // Restaurar al estado original
                        String estadoInicial = estadoOriginal[fila][col];
                        estadoParqueo[fila][col] = estadoInicial;
                        boton.setText(estadoInicial);
                        boton.setBackground(null);
                        JOptionPane.showMessageDialog(this, "Espacio liberado con éxito.");
                    } else {
                        JOptionPane.showMessageDialog(this, "Este espacio no está ocupado.");
                    }

                    espacioSeleccionado = true;
                }
            }
        }

        if (!espacioSeleccionado) {
            JOptionPane.showMessageDialog(this, "Seleccione un espacio para liberar.");
        }
    }

    private void configurarAccionesBotones() {
        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                int f = fila;
                int c = col;
                matrizBotones[fila][col].addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent evt) {
                        // Deseleccionar todos
                        for (int i = 0; i < matrizBotones.length; i++) {
                            for (int j = 0; j < matrizBotones[0].length; j++) {
                                matrizBotones[i][j].setBackground(null);
                            }
                        }
                        // Seleccionar el actual
                        matrizBotones[f][c].setBackground(Color.CYAN);
                    }
                });
            }
        }
    }

    private void mostrarInformacionEspacio() {
        boolean espacioSeleccionado = false;

        for (int fila = 0; fila < matrizBotones.length; fila++) {
            for (int col = 0; col < matrizBotones[0].length; col++) {
                JButton boton = matrizBotones[fila][col];

                if (boton.getBackground() != null && boton.getBackground().equals(Color.CYAN)) {
                    espacioSeleccionado = true;
                    String estado = estadoParqueo[fila][col];

                    switch (estado) {
                        case "L":
                            JOptionPane.showMessageDialog(this, "Este espacio está libre.");
                            break;
                        case "D":
                            JOptionPane.showMessageDialog(this, "Este espacio está reservado para personas con discapacidad.");
                            break;
                        case "E":
                            JOptionPane.showMessageDialog(this, "Este espacio está reservado para entrenadores.");
                            break;
                        case "O":
                            String id = parqueoIDs[fila][col];
                            String nombre = buscarNombrePorID(id);
                            JOptionPane.showMessageDialog(this, "Este espacio está ocupado por:\nID: " + id + "\nNombre: " + nombre);
                            break;
                        default:
                            JOptionPane.showMessageDialog(this, "Estado desconocido.");
                    }
                    return; // salir después de mostrar info del botón seleccionado
                }
            }
        }

        if (!espacioSeleccionado) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un espacio primero.");
        }
    }

    private String buscarNombrePorID(String idBuscado) {
        for (int i = 0; i < Socio_Registrar.contadorSocios; i++) {
            if (Socio_Registrar.socios[i][0].equals(idBuscado)) {
                return Socio_Registrar.socios[i][1]; // Posición 1 = nombre
            }
        }
        return "Desconocido";
    }
        private void escalarLogo() {
        // Carga la imagen desde recursos
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/iñasfit logo.jpg"));

        // Escala la imagen al tamaño del JLabel
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(
                Img_logo.getWidth(),
                Img_logo.getHeight(),
                Image.SCALE_SMOOTH
        );

        // Asigna la imagen escalada al JLabel
        Img_logo.setIcon(new ImageIcon(imagenEscalada));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pn_principal = new javax.swing.JPanel();
        pn_secundario2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        btn_socio = new javax.swing.JButton();
        btn_parqueo = new javax.swing.JButton();
        btn_pesas = new javax.swing.JButton();
        btn_cabinaAction = new javax.swing.JButton();
        btn_recreacion = new javax.swing.JButton();
        btn_auditorio = new javax.swing.JButton();
        Img_logo = new javax.swing.JLabel();
        btn_g3 = new javax.swing.JButton();
        btn_g1 = new javax.swing.JButton();
        btn_g2 = new javax.swing.JButton();
        btn_1_2 = new javax.swing.JButton();
        btn_1_1 = new javax.swing.JButton();
        btn_1_5 = new javax.swing.JButton();
        btn_1_3 = new javax.swing.JButton();
        btn_1_4 = new javax.swing.JButton();
        btn_2_2 = new javax.swing.JButton();
        btn_2_3 = new javax.swing.JButton();
        btn_2_4 = new javax.swing.JButton();
        btn_2_5 = new javax.swing.JButton();
        btn_3_4 = new javax.swing.JButton();
        btn_2_1 = new javax.swing.JButton();
        btn_3_3 = new javax.swing.JButton();
        btn_3_5 = new javax.swing.JButton();
        btn_3_1 = new javax.swing.JButton();
        btn_3_2 = new javax.swing.JButton();
        btn_4_3 = new javax.swing.JButton();
        btn_4_2 = new javax.swing.JButton();
        btn_4_4 = new javax.swing.JButton();
        btn_4_5 = new javax.swing.JButton();
        btn_4_1 = new javax.swing.JButton();
        btn_Pliberar = new javax.swing.JButton();
        btn_Pregistro = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_PInfo = new javax.swing.JButton();
        btn_5_1 = new javax.swing.JButton();
        btn_5_2 = new javax.swing.JButton();
        btn_5_3 = new javax.swing.JButton();
        btn_5_4 = new javax.swing.JButton();
        btn_5_5 = new javax.swing.JButton();
        btn_6_1 = new javax.swing.JButton();
        btn_6_2 = new javax.swing.JButton();
        btn_6_3 = new javax.swing.JButton();
        btn_6_4 = new javax.swing.JButton();
        btn_6_5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setResizable(false);

        pn_principal.setBackground(new java.awt.Color(255, 255, 255));

        pn_secundario2.setBackground(new java.awt.Color(0, 204, 204));
        pn_secundario2.setForeground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("Administracion  Gimnasio");

        btn_socio.setBackground(new java.awt.Color(0, 204, 204));
        btn_socio.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_socio.setForeground(new java.awt.Color(255, 255, 255));
        btn_socio.setText("Socio");
        btn_socio.setActionCommand("btn_socio");
        btn_socio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_socio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_socioActionPerformed(evt);
            }
        });

        btn_parqueo.setBackground(new java.awt.Color(0, 153, 153));
        btn_parqueo.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_parqueo.setForeground(new java.awt.Color(255, 255, 255));
        btn_parqueo.setText("Parqueo");
        btn_parqueo.setActionCommand("btn_parqueo");
        btn_parqueo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_parqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_parqueoActionPerformed(evt);
            }
        });

        btn_pesas.setBackground(new java.awt.Color(0, 204, 204));
        btn_pesas.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_pesas.setForeground(new java.awt.Color(255, 255, 255));
        btn_pesas.setText("Sala de pesas");
        btn_pesas.setActionCommand("btn_pesas");
        btn_pesas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_pesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pesasActionPerformed(evt);
            }
        });

        btn_cabinaAction.setBackground(new java.awt.Color(0, 204, 204));
        btn_cabinaAction.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_cabinaAction.setForeground(new java.awt.Color(255, 255, 255));
        btn_cabinaAction.setText("Cabinas");
        btn_cabinaAction.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_cabinaAction.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_cabinaAction.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_cabinaAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cabinaActionActionPerformed(evt);
            }
        });

        btn_recreacion.setBackground(new java.awt.Color(0, 204, 204));
        btn_recreacion.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_recreacion.setForeground(new java.awt.Color(255, 255, 255));
        btn_recreacion.setText("Recreación");
        btn_recreacion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_recreacion.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_recreacion.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_recreacion.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_recreacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_recreacionActionPerformed(evt);
            }
        });

        btn_auditorio.setBackground(new java.awt.Color(0, 204, 204));
        btn_auditorio.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_auditorio.setForeground(new java.awt.Color(255, 255, 255));
        btn_auditorio.setText("Auditorio");
        btn_auditorio.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_auditorio.setMaximumSize(new java.awt.Dimension(126, 30));
        btn_auditorio.setMinimumSize(new java.awt.Dimension(126, 30));
        btn_auditorio.setPreferredSize(new java.awt.Dimension(53, 30));
        btn_auditorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_auditorioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pn_secundario2Layout = new javax.swing.GroupLayout(pn_secundario2);
        pn_secundario2.setLayout(pn_secundario2Layout);
        pn_secundario2Layout.setHorizontalGroup(
            pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario2Layout.createSequentialGroup()
                .addGroup(pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_secundario2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pn_secundario2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pn_secundario2Layout.createSequentialGroup()
                                .addGroup(pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_socio, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_parqueo, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_pesas, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(btn_cabinaAction, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_secundario2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_recreacion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_auditorio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        pn_secundario2Layout.setVerticalGroup(
            pn_secundario2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_secundario2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_socio, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_parqueo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_pesas, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_cabinaAction, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_recreacion, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_auditorio, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Img_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Img_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iñasfit logo.jpg"))); // NOI18N
        Img_logo.setText("jLabel2");
        Img_logo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Img_logo.setIconTextGap(0);

        btn_g3.setBackground(new java.awt.Color(0, 204, 204));
        btn_g3.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_g3.setForeground(new java.awt.Color(255, 255, 255));
        btn_g3.setText("G3");
        btn_g3.setToolTipText("");
        btn_g3.setActionCommand("btn_informacionS");
        btn_g3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_g3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_g3btn_pesasActionPerformed(evt);
            }
        });

        btn_g1.setBackground(new java.awt.Color(0, 204, 204));
        btn_g1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_g1.setForeground(new java.awt.Color(255, 255, 255));
        btn_g1.setText("G1");
        btn_g1.setActionCommand("btn_registrarS");
        btn_g1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_g1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_g1btn_pesasActionPerformed(evt);
            }
        });

        btn_g2.setBackground(new java.awt.Color(0, 204, 204));
        btn_g2.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_g2.setForeground(new java.awt.Color(255, 255, 255));
        btn_g2.setText("G2");
        btn_g2.setActionCommand("btn_eliminarS");
        btn_g2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_g2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_g2btn_pesasActionPerformed(evt);
            }
        });

        btn_1_2.setText("L");
        btn_1_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_1_1.setText("D");
        btn_1_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btn_1_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1_1ActionPerformed(evt);
            }
        });

        btn_1_5.setText("E");
        btn_1_5.setActionCommand("L");
        btn_1_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_1_3.setText("L");
        btn_1_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_1_4.setText("L");
        btn_1_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_2.setText("L");
        btn_2_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_3.setText("L");
        btn_2_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_4.setText("L");
        btn_2_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_5.setText("L");
        btn_2_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_4.setText("L");
        btn_3_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_2_1.setText("D");
        btn_2_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_3.setText("L");
        btn_3_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_5.setText("L");
        btn_3_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_1.setText("D");
        btn_3_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_3_2.setText("L");
        btn_3_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_3.setText("L");
        btn_4_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_2.setText("L");
        btn_4_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_4.setText("L");
        btn_4_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_5.setText("E");
        btn_4_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_4_1.setText("D");
        btn_4_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btn_4_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_4_1ActionPerformed(evt);
            }
        });

        btn_Pliberar.setBackground(new java.awt.Color(0, 204, 204));
        btn_Pliberar.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_Pliberar.setForeground(new java.awt.Color(255, 255, 255));
        btn_Pliberar.setText("Liberar");
        btn_Pliberar.setActionCommand("btn_Pliberar");
        btn_Pliberar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_Pliberar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Pliberarbtn_pesasActionPerformed(evt);
            }
        });

        btn_Pregistro.setBackground(new java.awt.Color(0, 204, 204));
        btn_Pregistro.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_Pregistro.setForeground(new java.awt.Color(255, 255, 255));
        btn_Pregistro.setText("Registrar");
        btn_Pregistro.setActionCommand("btn_registrarS");
        btn_Pregistro.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_Pregistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Pregistrobtn_pesasActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("L-Liberar");

        jLabel2.setBackground(new java.awt.Color(153, 153, 153));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("O-Ocupado");

        jLabel3.setBackground(new java.awt.Color(153, 153, 153));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("E-Entrenador");

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("D-Discapacitado");

        btn_PInfo.setBackground(new java.awt.Color(0, 204, 204));
        btn_PInfo.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        btn_PInfo.setForeground(new java.awt.Color(255, 255, 255));
        btn_PInfo.setText("Informacion");
        btn_PInfo.setActionCommand("btn_Pliberar");
        btn_PInfo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        btn_PInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_PInfobtn_pesasActionPerformed(evt);
            }
        });

        btn_5_1.setText("L");
        btn_5_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_5_2.setText("L");
        btn_5_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_5_3.setText("L");
        btn_5_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_5_4.setText("L");
        btn_5_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_5_5.setText("L");
        btn_5_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_6_1.setText("L");
        btn_6_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_6_2.setText("L");
        btn_6_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_6_3.setText("L");
        btn_6_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_6_4.setText("L");
        btn_6_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btn_6_5.setText("L");
        btn_6_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        javax.swing.GroupLayout pn_principalLayout = new javax.swing.GroupLayout(pn_principal);
        pn_principal.setLayout(pn_principalLayout);
        pn_principalLayout.setHorizontalGroup(
            pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_principalLayout.createSequentialGroup()
                .addComponent(pn_secundario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addComponent(btn_g1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_g2, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pn_principalLayout.createSequentialGroup()
                                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btn_1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_5_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_6_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_2_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_3_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_4_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_5_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_5_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_5_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_5_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pn_principalLayout.createSequentialGroup()
                                        .addComponent(btn_6_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_6_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_6_4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_6_5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_g3, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)))
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addGap(210, 210, 210)
                        .addComponent(btn_Pliberar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_PInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(57, Short.MAX_VALUE))
            .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pn_principalLayout.createSequentialGroup()
                    .addGap(216, 216, 216)
                    .addComponent(btn_Pregistro, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(628, Short.MAX_VALUE)))
        );
        pn_principalLayout.setVerticalGroup(
            pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_secundario2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pn_principalLayout.createSequentialGroup()
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Img_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(46, 46, 46)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(78, 78, 78))
                    .addGroup(pn_principalLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_g1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_g2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_g3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_2_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_3_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_4_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_5_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_5_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_5_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_5_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_5_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_6_1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_6_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_6_3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_6_4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_6_5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Pliberar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_PInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
            .addGroup(pn_principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_principalLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Pregistro, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(43, 43, 43)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_principal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pn_principal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_g3btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_g3btn_pesasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_g3btn_pesasActionPerformed

    private void btn_g1btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_g1btn_pesasActionPerformed
        // TODO add your handling code here:
        Parqueo_G1 parqueo = new Parqueo_G1();
        parqueo.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_g1btn_pesasActionPerformed

    private void btn_g2btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_g2btn_pesasActionPerformed
        // TODO add your handling code here:
         Parqueo_G2 parqueo = new Parqueo_G2();

        parqueo.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_g2btn_pesasActionPerformed

    private void btn_1_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1_1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_1_1ActionPerformed

    private void btn_4_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_4_1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_4_1ActionPerformed

    private void btn_Pliberarbtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Pliberarbtn_pesasActionPerformed
        // TODO add your handling code here:
        liberarEspacio();
    }//GEN-LAST:event_btn_Pliberarbtn_pesasActionPerformed

    private void btn_Pregistrobtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Pregistrobtn_pesasActionPerformed
        // TODO add your handling code here:
        registrarOcupacion();
    }//GEN-LAST:event_btn_Pregistrobtn_pesasActionPerformed

    private void btn_PInfobtn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_PInfobtn_pesasActionPerformed
        // TODO add your handling code here:
        mostrarInformacionEspacio();
    }//GEN-LAST:event_btn_PInfobtn_pesasActionPerformed

    private void btn_socioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_socioActionPerformed
        // TODO add your handling code here:
        Socio socio = new Socio();

        socio.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_socioActionPerformed

    private void btn_parqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_parqueoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_parqueoActionPerformed

    private void btn_pesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pesasActionPerformed
        // TODO add your handling code here:
        Sala_Pesas sala_pesas = new Sala_Pesas();

        sala_pesas.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_pesasActionPerformed

    private void btn_cabinaActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cabinaActionActionPerformed
        Cabina cabinas = new Cabina();

        cabinas.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_cabinaActionActionPerformed

    private void btn_recreacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_recreacionActionPerformed
        // TODO add your handling code here:
        Recreacion recreacion = new Recreacion();

        recreacion.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_recreacionActionPerformed

    private void btn_auditorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_auditorioActionPerformed
        Auditorio auditorio = new Auditorio();

        auditorio.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_auditorioActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Parqueo_G3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Parqueo_G3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Img_logo;
    private javax.swing.JButton btn_1_1;
    private javax.swing.JButton btn_1_2;
    private javax.swing.JButton btn_1_3;
    private javax.swing.JButton btn_1_4;
    private javax.swing.JButton btn_1_5;
    private javax.swing.JButton btn_2_1;
    private javax.swing.JButton btn_2_2;
    private javax.swing.JButton btn_2_3;
    private javax.swing.JButton btn_2_4;
    private javax.swing.JButton btn_2_5;
    private javax.swing.JButton btn_3_1;
    private javax.swing.JButton btn_3_2;
    private javax.swing.JButton btn_3_3;
    private javax.swing.JButton btn_3_4;
    private javax.swing.JButton btn_3_5;
    private javax.swing.JButton btn_4_1;
    private javax.swing.JButton btn_4_2;
    private javax.swing.JButton btn_4_3;
    private javax.swing.JButton btn_4_4;
    private javax.swing.JButton btn_4_5;
    private javax.swing.JButton btn_5_1;
    private javax.swing.JButton btn_5_2;
    private javax.swing.JButton btn_5_3;
    private javax.swing.JButton btn_5_4;
    private javax.swing.JButton btn_5_5;
    private javax.swing.JButton btn_6_1;
    private javax.swing.JButton btn_6_2;
    private javax.swing.JButton btn_6_3;
    private javax.swing.JButton btn_6_4;
    private javax.swing.JButton btn_6_5;
    private javax.swing.JButton btn_PInfo;
    private javax.swing.JButton btn_Pliberar;
    private javax.swing.JButton btn_Pregistro;
    private javax.swing.JButton btn_auditorio;
    private javax.swing.JButton btn_cabinaAction;
    private javax.swing.JButton btn_g1;
    private javax.swing.JButton btn_g2;
    private javax.swing.JButton btn_g3;
    private javax.swing.JButton btn_parqueo;
    private javax.swing.JButton btn_pesas;
    private javax.swing.JButton btn_recreacion;
    private javax.swing.JButton btn_socio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel pn_principal;
    private javax.swing.JPanel pn_secundario2;
    // End of variables declaration//GEN-END:variables
}
